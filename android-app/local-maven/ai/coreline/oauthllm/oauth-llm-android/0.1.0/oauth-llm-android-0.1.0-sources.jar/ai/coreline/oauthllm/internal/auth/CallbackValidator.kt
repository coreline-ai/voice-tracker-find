package ai.coreline.oauthllm.internal.auth

import java.net.URI
import java.net.URLDecoder
import java.security.MessageDigest

internal sealed interface CallbackValidationResult {
    data class AuthorizationCode(val code: String) : CallbackValidationResult
    data class ProviderError(val error: String) : CallbackValidationResult
    data class Rejected(val reason: Rejection) : CallbackValidationResult
}

internal enum class Rejection {
    INVALID_URI,
    WRONG_REDIRECT,
    INVALID_PARAMETERS,
    STATE_MISMATCH,
    EXPIRED,
}

internal object CallbackValidator {
    private const val MAX_URI_CHARS = 16 * 1024
    private const val MAX_PARAMETER_CHARS = 4 * 1024
    private const val MAX_PARAMETER_COUNT = 16
    private val SENSITIVE_KEYS = setOf("code", "state", "error", "error_description")

    fun validate(
        callbackUri: String,
        transaction: PendingAuthTransaction,
        nowEpochMillis: Long,
    ): CallbackValidationResult {
        if (callbackUri.length > MAX_URI_CHARS || containsLineBreak(callbackUri)) {
            return CallbackValidationResult.Rejected(Rejection.INVALID_URI)
        }
        if (nowEpochMillis !in transaction.createdAtEpochMillis..transaction.expiresAtEpochMillis) {
            return CallbackValidationResult.Rejected(Rejection.EXPIRED)
        }
        val expected = runCatching { URI(transaction.redirectUri) }.getOrNull()
            ?: return CallbackValidationResult.Rejected(Rejection.INVALID_URI)
        val actual = runCatching { URI(callbackUri) }.getOrNull()
            ?: return CallbackValidationResult.Rejected(Rejection.INVALID_URI)
        if (
            actual.scheme != expected.scheme ||
            !actual.host.equals(expected.host, ignoreCase = true) ||
            actual.port != expected.port ||
            actual.path != expected.path ||
            actual.userInfo != null ||
            actual.fragment != null
        ) {
            return CallbackValidationResult.Rejected(Rejection.WRONG_REDIRECT)
        }

        val values = parseQuery(actual.rawQuery ?: "")
            ?: return CallbackValidationResult.Rejected(Rejection.INVALID_PARAMETERS)
        if (SENSITIVE_KEYS.any { values[it].orEmpty().size > 1 }) {
            return CallbackValidationResult.Rejected(Rejection.INVALID_PARAMETERS)
        }
        val state = values["state"]?.singleOrNull()
            ?: return CallbackValidationResult.Rejected(Rejection.STATE_MISMATCH)
        if (!constantTimeEquals(state, transaction.state)) {
            return CallbackValidationResult.Rejected(Rejection.STATE_MISMATCH)
        }
        val code = values["code"]?.singleOrNull()
        val error = values["error"]?.singleOrNull()
        if ((code == null) == (error == null)) {
            return CallbackValidationResult.Rejected(Rejection.INVALID_PARAMETERS)
        }
        if (code != null && code.isNotBlank()) return CallbackValidationResult.AuthorizationCode(code)
        if (error != null && error.isNotBlank()) return CallbackValidationResult.ProviderError(error)
        return CallbackValidationResult.Rejected(Rejection.INVALID_PARAMETERS)
    }

    private fun parseQuery(rawQuery: String): Map<String, List<String>>? {
        if (rawQuery.isBlank()) return emptyMap()
        val pairs = rawQuery.split('&')
        if (pairs.size > MAX_PARAMETER_COUNT) return null
        val values = linkedMapOf<String, MutableList<String>>()
        for (pair in pairs) {
            val pieces = pair.split('=', limit = 2)
            val key = decode(pieces[0]) ?: return null
            val value = decode(pieces.getOrElse(1) { "" }) ?: return null
            if (
                key.isBlank() || key.length > MAX_PARAMETER_CHARS || value.length > MAX_PARAMETER_CHARS ||
                containsLineBreak(key) || containsLineBreak(value)
            ) return null
            values.getOrPut(key) { mutableListOf() }.add(value)
        }
        return values
    }

    private fun decode(value: String): String? = runCatching {
        URLDecoder.decode(value, Charsets.UTF_8.name())
    }.getOrNull()

    private fun constantTimeEquals(left: String, right: String): Boolean = MessageDigest.isEqual(
        left.toByteArray(Charsets.UTF_8),
        right.toByteArray(Charsets.UTF_8),
    )

    private fun containsLineBreak(value: String): Boolean = value.any { it == '\r' || it == '\n' }
}

