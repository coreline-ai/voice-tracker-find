package ai.coreline.oauthllm.internal.provider

import ai.coreline.oauthllm.api.LlmProvider

internal enum class TokenEncoding { JSON, FORM }

internal data class ProviderSpec(
    val provider: LlmProvider,
    val authorizationEndpoint: String,
    val tokenEndpoint: String,
    val inferenceEndpoint: String,
    val scopes: List<String>,
    val redirectHost: String,
    val redirectPort: Int,
    val redirectPath: String,
    val tokenEncoding: TokenEncoding,
    val pkceKind: PkceKind,
    val includeNonce: Boolean,
    val oidcIssuer: String?,
    val oidcJwksEndpoint: String?,
    val oidcSigningAlgorithm: String?,
    val authorizationExtras: Map<String, String>,
    val tokenNetworkAttempts: Int,
    val allowedAuthorizationHost: String,
    val allowedTokenHost: String,
    val allowedInferenceHost: String,
) {
    val redirectUri: String get() = "http://$redirectHost:$redirectPort$redirectPath"
}

internal enum class PkceKind { STANDARD, LONG_BASE64_URL, HEX }

internal object ProviderSpecs {
    fun forProvider(provider: LlmProvider): ProviderSpec = when (provider) {
        LlmProvider.ANTHROPIC -> ProviderSpec(
            provider = provider,
            authorizationEndpoint = "https://claude.ai/oauth/authorize",
            tokenEndpoint = "https://console.anthropic.com/v1/oauth/token",
            inferenceEndpoint = "https://api.anthropic.com/v1/messages",
            scopes = listOf("org:create_api_key", "user:profile", "user:inference"),
            redirectHost = "localhost",
            redirectPort = 54545,
            redirectPath = "/callback",
            tokenEncoding = TokenEncoding.JSON,
            pkceKind = PkceKind.LONG_BASE64_URL,
            includeNonce = false,
            oidcIssuer = null,
            oidcJwksEndpoint = null,
            oidcSigningAlgorithm = null,
            authorizationExtras = emptyMap(),
            tokenNetworkAttempts = 1,
            allowedAuthorizationHost = "claude.ai",
            allowedTokenHost = "console.anthropic.com",
            allowedInferenceHost = "api.anthropic.com",
        )
        LlmProvider.CODEX -> ProviderSpec(
            provider = provider,
            authorizationEndpoint = "https://auth.openai.com/oauth/authorize",
            tokenEndpoint = "https://auth.openai.com/oauth/token",
            inferenceEndpoint = "https://chatgpt.com/backend-api/codex/responses",
            scopes = listOf("openid", "profile", "email", "offline_access"),
            redirectHost = "localhost",
            redirectPort = 1455,
            redirectPath = "/auth/callback",
            tokenEncoding = TokenEncoding.FORM,
            pkceKind = PkceKind.STANDARD,
            includeNonce = true,
            oidcIssuer = "https://auth.openai.com",
            oidcJwksEndpoint = "https://auth.openai.com/.well-known/jwks.json",
            oidcSigningAlgorithm = "RS256",
            authorizationExtras = mapOf(
                "codex_cli_simplified_flow" to "true",
                "originator" to "codex_cli_rs",
                "id_token_add_organizations" to "true",
            ),
            tokenNetworkAttempts = 3,
            allowedAuthorizationHost = "auth.openai.com",
            allowedTokenHost = "auth.openai.com",
            allowedInferenceHost = "chatgpt.com",
        )
        LlmProvider.XAI -> ProviderSpec(
            provider = provider,
            authorizationEndpoint = "https://auth.x.ai/oauth2/authorize",
            tokenEndpoint = "https://auth.x.ai/oauth2/token",
            inferenceEndpoint = "https://api.x.ai/v1/chat/completions",
            scopes = listOf(
                "openid",
                "profile",
                "email",
                "offline_access",
                "grok-cli:access",
                "api:access",
            ),
            redirectHost = "127.0.0.1",
            redirectPort = 56121,
            redirectPath = "/callback",
            tokenEncoding = TokenEncoding.FORM,
            pkceKind = PkceKind.HEX,
            includeNonce = true,
            oidcIssuer = "https://auth.x.ai",
            oidcJwksEndpoint = "https://auth.x.ai/.well-known/jwks.json",
            oidcSigningAlgorithm = "ES256",
            authorizationExtras = mapOf(
                "plan" to "generic",
                "referrer" to "oauth-llm-sdk-android",
            ),
            tokenNetworkAttempts = 3,
            allowedAuthorizationHost = "auth.x.ai",
            allowedTokenHost = "auth.x.ai",
            allowedInferenceHost = "api.x.ai",
        )
    }
}
