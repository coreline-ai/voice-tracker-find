package ai.coreline.oauthllm.android

import android.content.Context
import android.content.Intent
import ai.coreline.oauthllm.api.ConnectRequest
import ai.coreline.oauthllm.api.ConnectResult
import ai.coreline.oauthllm.api.LlmProvider
import ai.coreline.oauthllm.api.LlmSessionClient
import ai.coreline.oauthllm.internal.AndroidOAuthLlmClientImpl

/** Android-specific interactive connection surface layered over the Android-independent client. */
public interface AndroidOAuthLlmClient : LlmSessionClient {
    public fun createConnectIntent(request: ConnectRequest): Intent

    public suspend fun completeConnect(resultData: Intent?): ConnectResult
}

/** Public-client registration. A client secret is intentionally not representable. */
public data class OAuthProviderRegistration(
    public val provider: LlmProvider,
    public val clientId: String,
)

public data class AndroidOAuthLlmConfiguration(
    public val registrations: Set<OAuthProviderRegistration>,
    public val transactionTimeoutMillis: Long = 5 * 60 * 1_000L,
)

/** Creates an independent SDK client backed by Android Keystore and app-private storage. */
public object AndroidOAuthLlm {
    @JvmStatic
    public fun create(
        context: Context,
        configuration: AndroidOAuthLlmConfiguration,
    ): AndroidOAuthLlmClient = AndroidOAuthLlmClientImpl(context.applicationContext, configuration)
}

