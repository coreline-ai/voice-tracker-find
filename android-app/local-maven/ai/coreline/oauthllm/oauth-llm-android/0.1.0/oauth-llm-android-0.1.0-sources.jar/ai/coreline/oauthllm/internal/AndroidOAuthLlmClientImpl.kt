package ai.coreline.oauthllm.internal

import android.content.Context
import android.content.Intent
import ai.coreline.oauthllm.android.AndroidOAuthLlmClient
import ai.coreline.oauthllm.android.AndroidOAuthLlmConfiguration
import ai.coreline.oauthllm.api.ConnectRequest
import ai.coreline.oauthllm.api.ConnectResult
import ai.coreline.oauthllm.api.DisconnectResult
import ai.coreline.oauthllm.api.LlmConnection
import ai.coreline.oauthllm.api.LlmGenerateRequest
import ai.coreline.oauthllm.api.LlmGenerateResult
import ai.coreline.oauthllm.api.OAuthLlmException
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID

internal class AndroidOAuthLlmClientImpl(
    private val context: Context,
    configuration: AndroidOAuthLlmConfiguration,
) : AndroidOAuthLlmClient {
    private val runtimeId = UUID.randomUUID().toString()
    private val runtime = ClientRuntime(context, configuration)
    private var closed = false

    init {
        OAuthRuntimeRegistry.register(runtimeId, runtime)
    }

    override val connections: StateFlow<List<LlmConnection>> = runtime.connections

    override fun createConnectIntent(request: ConnectRequest): Intent {
        check(!closed) { "OAuth LLM client is closed" }
        return Intent(context, OAuthConnectActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra(ClientResultCodec.EXTRA_RUNTIME_ID, runtimeId)
            .putExtra(ClientResultCodec.EXTRA_PROVIDER_ID, request.provider.id)
            .putExtra(ClientResultCodec.EXTRA_DISPLAY_NAME, request.displayName)
    }

    override suspend fun completeConnect(resultData: Intent?): ConnectResult =
        ClientResultCodec.decode(resultData) { profileId ->
            connections.value.firstOrNull { it.profileId == profileId }
        }

    override suspend fun generate(
        profileId: String,
        request: LlmGenerateRequest,
    ): LlmGenerateResult {
        check(!closed) { "OAuth LLM client is closed" }
        return try {
            runtime.generate(profileId, request)
        } catch (error: ai.coreline.oauthllm.internal.http.InternalSdkException) {
            throw OAuthLlmException(ClientResultCodec.failure(error))
        }
    }

    override suspend fun disconnect(profileId: String): DisconnectResult {
        check(!closed) { "OAuth LLM client is closed" }
        return try {
            runtime.disconnect(profileId)
        } catch (error: ai.coreline.oauthllm.internal.http.InternalSdkException) {
            throw OAuthLlmException(ClientResultCodec.failure(error))
        }
    }

    override fun close() {
        if (!closed) {
            closed = true
            OAuthRuntimeRegistry.unregister(runtimeId)
            runtime.close()
        }
    }
}
