package ai.coreline.oauthllm.internal.http

internal enum class InternalFailureKind {
    NOT_CONNECTED,
    AUTHENTICATION_REQUIRED,
    NETWORK_UNAVAILABLE,
    RATE_LIMITED,
    PROVIDER_UNAVAILABLE,
    TIMEOUT,
    INVALID_RESPONSE,
    INVALID_REQUEST,
    USER_CANCELLED,
}

internal class InternalSdkException(
    val kind: InternalFailureKind,
    val retryAfterMillis: Long? = null,
    val safeRequestId: String? = null,
    val httpStatus: Int? = null,
) : Exception("OAuth LLM operation failed: ${kind.name}")
