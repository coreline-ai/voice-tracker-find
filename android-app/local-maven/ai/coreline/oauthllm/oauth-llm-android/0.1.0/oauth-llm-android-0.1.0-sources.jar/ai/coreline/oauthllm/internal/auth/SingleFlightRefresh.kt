package ai.coreline.oauthllm.internal.auth

import ai.coreline.oauthllm.internal.http.InternalFailureKind
import ai.coreline.oauthllm.internal.http.InternalSdkException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap

internal interface CredentialStore {
    fun load(profileId: String): StoredCredential?
    fun save(credential: StoredCredential)
    fun remove(profileId: String)
    fun profiles(): List<StoredCredential>
}

internal fun interface CredentialRefresher {
    suspend fun refresh(credential: StoredCredential, refreshToken: String): TokenGrant
}

internal class SingleFlightRefresh(
    private val store: CredentialStore,
    private val refresher: CredentialRefresher,
    private val now: () -> Long = System::currentTimeMillis,
    private val refreshSkewMillis: Long = 5 * 60 * 1000L,
) {
    suspend fun validCredential(profileId: String, rejectedAccessToken: String? = null): StoredCredential? =
        PROCESS_LOCKS.getOrPut(profileId) { Mutex() }.withLock {
            val current = store.load(profileId) ?: return@withLock null
            if (rejectedAccessToken != null && current.accessToken != rejectedAccessToken) {
                return@withLock current
            }
            if (rejectedAccessToken == null && current.isUsable(now(), refreshSkewMillis)) {
                return@withLock current
            }
            val refreshToken = current.refreshToken
            if (refreshToken.isNullOrBlank()) {
                if (rejectedAccessToken != null || !current.isUsable(now(), 0)) store.remove(profileId)
                return@withLock current.takeIf { it.isUsable(now(), 0) }
            }
            val grant = try {
                refresher.refresh(current, refreshToken)
            } catch (error: InternalSdkException) {
                if (error.kind == InternalFailureKind.AUTHENTICATION_REQUIRED) {
                    store.remove(profileId)
                    return@withLock null
                }
                throw error
            }
            val rotated = current.copy(
                accessToken = grant.accessToken,
                refreshToken = grant.refreshToken ?: current.refreshToken,
                idToken = grant.idToken ?: current.idToken,
                accountId = grant.accountId ?: current.accountId,
                expiresAtEpochMillis = grant.expiresInSeconds?.let { now() + it * 1000L },
                updatedAtEpochMillis = now(),
            )
            store.save(rotated)
            rotated
        }

    private companion object {
        // All clients in this app process share the same encrypted credential namespace.
        val PROCESS_LOCKS = ConcurrentHashMap<String, Mutex>()
    }
}
