package ai.coreline.oauthllm.internal.http

import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl

internal object EndpointAllowlist {
    fun requireExactHttps(url: HttpUrl, expectedUrl: String, expectedHost: String) {
        val expected = expectedUrl.toHttpUrl()
        require(
            url.scheme == "https" &&
                url.host == expectedHost &&
                url == expected &&
                url.username.isEmpty() &&
                url.password.isEmpty(),
        ) { "Provider endpoint is not allowlisted" }
    }
}
