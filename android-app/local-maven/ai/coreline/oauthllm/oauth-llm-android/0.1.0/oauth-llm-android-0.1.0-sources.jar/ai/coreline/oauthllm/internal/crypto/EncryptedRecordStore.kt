package ai.coreline.oauthllm.internal.crypto

import android.content.Context
import android.content.SharedPreferences
import ai.coreline.oauthllm.internal.http.InternalFailureKind
import ai.coreline.oauthllm.internal.http.InternalSdkException
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Base64

internal interface EncryptedRecordStore {
    fun put(recordType: String, recordId: String, plaintext: String)
    fun get(recordType: String, recordId: String): String?
    fun remove(recordType: String, recordId: String)
}

internal class KeystoreEncryptedRecordStore(
    context: Context,
    private val preferences: SharedPreferences = context.applicationContext.getSharedPreferences(
        "ai.coreline.oauthllm.encrypted.v1",
        Context.MODE_PRIVATE,
    ),
    private val keyProvider: AndroidKeyProvider = AndroidKeyProvider(),
) : EncryptedRecordStore {
    override fun put(recordType: String, recordId: String, plaintext: String) {
        synchronized(PROCESS_STORE_LOCK) {
            try {
                val storageKey = storageKey(recordType, recordId)
                val encrypted = AesGcmBox(keyProvider.getOrCreate()).encrypt(
                    plaintext.toByteArray(StandardCharsets.UTF_8),
                    storageKey.toByteArray(StandardCharsets.UTF_8),
                )
                if (!preferences.edit().putString(storageKey, Base64.getEncoder().encodeToString(encrypted)).commit()) {
                    throw IllegalStateException()
                }
            } catch (_: Exception) {
                throw InternalSdkException(InternalFailureKind.INVALID_RESPONSE)
            }
        }
    }

    override fun get(recordType: String, recordId: String): String? {
        synchronized(PROCESS_STORE_LOCK) {
            try {
                val storageKey = storageKey(recordType, recordId)
                val encoded = preferences.getString(storageKey, null) ?: return null
                val plaintext = AesGcmBox(keyProvider.getOrCreate()).decrypt(
                    Base64.getDecoder().decode(encoded),
                    storageKey.toByteArray(StandardCharsets.UTF_8),
                )
                return plaintext.toString(StandardCharsets.UTF_8)
            } catch (_: Exception) {
                throw InternalSdkException(InternalFailureKind.INVALID_RESPONSE)
            }
        }
    }

    override fun remove(recordType: String, recordId: String) {
        synchronized(PROCESS_STORE_LOCK) {
            try {
                if (!preferences.edit().remove(storageKey(recordType, recordId)).commit()) {
                    throw IllegalStateException()
                }
            } catch (_: Exception) {
                throw InternalSdkException(InternalFailureKind.INVALID_RESPONSE)
            }
        }
    }

    private fun storageKey(recordType: String, recordId: String): String {
        require(recordType.matches(SAFE_TYPE)) { "Invalid record type" }
        require(recordId.isNotBlank() && recordId.length <= 256) { "Invalid record id" }
        val digest = MessageDigest.getInstance("SHA-256").digest(
            "$recordType\u0000$recordId".toByteArray(StandardCharsets.UTF_8),
        )
        return "v1.$recordType.${Base64.getUrlEncoder().withoutPadding().encodeToString(digest)}"
    }

    private companion object {
        val PROCESS_STORE_LOCK = Any()
        val SAFE_TYPE = Regex("[a-z][a-z0-9_-]{0,31}")
    }
}
