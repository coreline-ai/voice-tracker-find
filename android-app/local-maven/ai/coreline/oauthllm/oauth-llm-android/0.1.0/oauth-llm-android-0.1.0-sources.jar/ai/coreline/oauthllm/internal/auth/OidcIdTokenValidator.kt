package ai.coreline.oauthllm.internal.auth

import ai.coreline.oauthllm.internal.http.EndpointAllowlist
import ai.coreline.oauthllm.internal.http.InternalFailureKind
import ai.coreline.oauthllm.internal.http.InternalSdkException
import ai.coreline.oauthllm.internal.http.readUtf8Bounded
import ai.coreline.oauthllm.internal.provider.ProviderSpec
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.math.BigInteger
import java.nio.charset.StandardCharsets
import java.security.AlgorithmParameters
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.ECPoint
import java.security.spec.ECPublicKeySpec
import java.security.spec.RSAPublicKeySpec
import java.util.Base64
import kotlin.coroutines.resume
import kotlin.math.abs

/** Full OIDC signature and claim validation; the encoded ID token is discarded by the caller. */
internal class OidcIdTokenValidator(
    private val httpClient: OkHttpClient,
    private val now: () -> Long,
) {
    suspend fun validate(
        encoded: String,
        spec: ProviderSpec,
        expectedAudience: String,
        expectedNonce: String,
    ): JSONObject {
        try {
            require(encoded.length in 16..MAX_ID_TOKEN_CHARS)
            val sections = encoded.split('.')
            require(sections.size == 3)
            val header = decodeObject(sections[0])
            val algorithm = requireNotNull(spec.oidcSigningAlgorithm)
            require(header.getString("alg") == algorithm)
            val keyId = header.getString("kid")
            require(keyId.length in 1..256 && keyId.all { it.code in 0x21..0x7e })
            val jwk = loadJwk(spec, keyId, algorithm)
            val signatureBytes = Base64.getUrlDecoder().decode(sections[2])
            val signedBytes = "${sections[0]}.${sections[1]}".toByteArray(StandardCharsets.US_ASCII)
            require(verify(algorithm, jwk, signedBytes, signatureBytes))

            val claims = decodeObject(sections[1])
            require(claims.getString("iss") == requireNotNull(spec.oidcIssuer))
            require(claims.getString("nonce") == expectedNonce)
            require(claims.getString("sub").isNotBlank())
            require(audienceContains(claims.get("aud"), expectedAudience))
            val nowSeconds = now() / 1_000L
            require(claims.getLong("exp") >= nowSeconds)
            require(abs(claims.getLong("iat") - nowSeconds) <= IAT_SKEW_SECONDS)
            return claims
        } catch (error: InternalSdkException) {
            throw error
        } catch (_: Exception) {
            throw InternalSdkException(InternalFailureKind.INVALID_RESPONSE)
        }
    }

    private suspend fun loadJwk(spec: ProviderSpec, keyId: String, algorithm: String): JSONObject {
        val endpointText = requireNotNull(spec.oidcJwksEndpoint)
        val endpoint = endpointText.toHttpUrl()
        EndpointAllowlist.requireExactHttps(endpoint, endpointText, spec.allowedTokenHost)
        val response = try {
            httpClient.newCall(
                Request.Builder().url(endpoint).header("Accept", "application/json").get().build(),
            ).await()
        } catch (_: IOException) {
            throw InternalSdkException(InternalFailureKind.NETWORK_UNAVAILABLE)
        }
        response.use {
            if (!it.isSuccessful) throw InternalSdkException(InternalFailureKind.INVALID_RESPONSE)
            val body = it.body?.readUtf8Bounded(MAX_JWKS_BYTES)
                ?: throw InternalSdkException(InternalFailureKind.INVALID_RESPONSE)
            val keys = JSONObject(body).getJSONArray("keys")
            require(keys.length() in 1..MAX_JWK_COUNT)
            return (0 until keys.length())
                .map { index -> keys.getJSONObject(index) }
                .single { key ->
                    key.optString("kid") == keyId &&
                        key.optString("alg", algorithm) == algorithm &&
                        key.optString("use", "sig") == "sig"
                }
        }
    }

    private fun verify(
        algorithm: String,
        jwk: JSONObject,
        signedBytes: ByteArray,
        signatureBytes: ByteArray,
    ): Boolean {
        val (javaAlgorithm, publicKey, normalizedSignature) = when (algorithm) {
            "RS256" -> {
                require(jwk.getString("kty") == "RSA")
                val modulus = BigInteger(1, decode(jwk.getString("n")))
                val exponent = BigInteger(1, decode(jwk.getString("e")))
                Triple(
                    "SHA256withRSA",
                    KeyFactory.getInstance("RSA").generatePublic(RSAPublicKeySpec(modulus, exponent)),
                    signatureBytes,
                )
            }
            "ES256" -> {
                require(jwk.getString("kty") == "EC" && jwk.getString("crv") == "P-256")
                val parameters = AlgorithmParameters.getInstance("EC").apply {
                    init(ECGenParameterSpec("secp256r1"))
                }.getParameterSpec(java.security.spec.ECParameterSpec::class.java)
                val point = ECPoint(
                    BigInteger(1, decode(jwk.getString("x"))),
                    BigInteger(1, decode(jwk.getString("y"))),
                )
                Triple(
                    "SHA256withECDSA",
                    KeyFactory.getInstance("EC").generatePublic(ECPublicKeySpec(point, parameters)),
                    joseEcdsaToDer(signatureBytes),
                )
            }
            else -> throw IllegalArgumentException()
        }
        return Signature.getInstance(javaAlgorithm).run {
            initVerify(publicKey)
            update(signedBytes)
            verify(normalizedSignature)
        }
    }

    private fun audienceContains(audience: Any, expected: String): Boolean = when (audience) {
        is String -> audience == expected
        is JSONArray -> (0 until audience.length()).any { audience.getString(it) == expected }
        else -> false
    }

    private fun decodeObject(value: String): JSONObject =
        JSONObject(String(decode(value), StandardCharsets.UTF_8))

    private fun decode(value: String): ByteArray = Base64.getUrlDecoder().decode(value)

    private fun joseEcdsaToDer(raw: ByteArray): ByteArray {
        require(raw.size == 64)
        fun integer(bytes: ByteArray): ByteArray {
            val candidate = bytes.dropWhile { it == 0.toByte() }.toByteArray()
            val stripped = if (candidate.isEmpty()) byteArrayOf(0) else candidate
            return if (stripped[0].toInt() and 0x80 != 0) byteArrayOf(0) + stripped else stripped
        }
        val r = integer(raw.copyOfRange(0, 32))
        val s = integer(raw.copyOfRange(32, 64))
        val bodyLength = 2 + r.size + 2 + s.size
        require(bodyLength < 128)
        return byteArrayOf(0x30, bodyLength.toByte(), 0x02, r.size.toByte()) + r +
            byteArrayOf(0x02, s.size.toByte()) + s
    }

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { continuation ->
        continuation.invokeOnCancellation { cancel() }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (continuation.isActive) continuation.resumeWith(Result.failure(e))
            }

            override fun onResponse(call: Call, response: Response) {
                if (continuation.isActive) continuation.resume(response) else response.close()
            }
        })
    }

    private companion object {
        const val MAX_ID_TOKEN_CHARS = 64 * 1024
        const val MAX_JWKS_BYTES = 256L * 1024L
        const val MAX_JWK_COUNT = 32
        const val IAT_SKEW_SECONDS = 10 * 60L
    }
}
