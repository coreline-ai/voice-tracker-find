package ai.coreline.oauthllm.internal

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import ai.coreline.oauthllm.api.ConnectResult
import ai.coreline.oauthllm.api.LlmProvider
import ai.coreline.oauthllm.api.OAuthLlmFailure
import ai.coreline.oauthllm.internal.auth.EncryptedPendingTransactionStore
import ai.coreline.oauthllm.internal.crypto.KeystoreEncryptedRecordStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

internal class OAuthConnectActivity : Activity() {
    private val activityScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var transactionId: String? = null
    private var runtime: ClientRuntime? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildContent()
        val restoredId = savedInstanceState?.getString(ClientResultCodec.EXTRA_TRANSACTION_ID)
        runtime = OAuthRuntimeRegistry.find(intent.getStringExtra(ClientResultCodec.EXTRA_RUNTIME_ID))
        if (runtime == null) {
            restoredId?.let { id ->
                EncryptedPendingTransactionStore(KeystoreEncryptedRecordStore(applicationContext))
                    .remove(id)
            }
            finishWith(ConnectResult.Failed(OAuthLlmFailure.AuthenticationRequired))
            return
        }
        if (restoredId != null) {
            transactionId = restoredId
            val handle = runtime?.attach(restoredId)
            if (handle == null) {
                finishWith(ConnectResult.Failed(OAuthLlmFailure.AuthenticationRequired))
            } else {
                await(handle)
            }
            return
        }
        val providerId = intent.getStringExtra(ClientResultCodec.EXTRA_PROVIDER_ID)
        val provider = LlmProvider.entries.firstOrNull { it.id == providerId }
        if (provider == null) {
            finishWith(ConnectResult.Failed(OAuthLlmFailure.InvalidRequest))
            return
        }
        val displayName = intent.getStringExtra(ClientResultCodec.EXTRA_DISPLAY_NAME)
        activityScope.launch {
            val handle = try {
                runtime?.beginConnect(provider, displayName)
                    ?: return@launch finishWith(
                        ConnectResult.Failed(OAuthLlmFailure.AuthenticationRequired),
                    )
            } catch (error: ai.coreline.oauthllm.internal.http.InternalSdkException) {
                return@launch finishWith(ConnectResult.Failed(ClientResultCodec.failure(error)))
            }
            transactionId = handle.transactionId
            try {
                startActivity(requireNotNull(handle.browserIntent))
            } catch (_: Exception) {
                runtime?.cancel(handle.transactionId)
                return@launch finishWith(ConnectResult.Failed(OAuthLlmFailure.ProviderUnavailable))
            }
            await(handle)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        transactionId?.let { outState.putString(ClientResultCodec.EXTRA_TRANSACTION_ID, it) }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        cancelConnect()
    }

    override fun onDestroy() {
        activityScope.cancel()
        super.onDestroy()
    }

    private fun await(handle: ConnectFlowHandle) {
        activityScope.launch {
            val result = handle.result.await()
            runtime?.release(handle.transactionId)
            finishWith(result)
        }
    }

    private fun cancelConnect() {
        transactionId?.let { runtime?.cancel(it) }
        finishWith(ConnectResult.Cancelled)
    }

    private fun finishWith(result: ConnectResult) {
        setResult(RESULT_OK, ClientResultCodec.encode(result))
        finish()
    }

    private fun buildContent() {
        val density = resources.displayMetrics.density
        val padding = (24 * density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(padding, padding, padding, padding)
            addView(ProgressBar(this@OAuthConnectActivity))
            addView(TextView(this@OAuthConnectActivity).apply {
                text = "Complete authorization in your browser."
                gravity = Gravity.CENTER
                setPadding(0, padding, 0, padding)
            })
            addView(Button(this@OAuthConnectActivity).apply {
                text = "Cancel"
                setOnClickListener { cancelConnect() }
            })
        }
        setContentView(layout)
    }
}
