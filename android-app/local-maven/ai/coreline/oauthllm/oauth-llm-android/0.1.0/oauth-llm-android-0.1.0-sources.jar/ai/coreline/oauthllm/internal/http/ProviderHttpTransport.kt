package ai.coreline.oauthllm.internal.http

import ai.coreline.oauthllm.internal.auth.StoredCredential
import ai.coreline.oauthllm.internal.provider.ProviderRequestPayload
import ai.coreline.oauthllm.internal.provider.ProviderSpec
import ai.coreline.oauthllm.internal.provider.ProviderWireAdapter
import ai.coreline.oauthllm.internal.provider.ProviderWireResult
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.io.InterruptedIOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

internal data class TimedProviderResult(
    val wire: ProviderWireResult,
    val providerRequestId: String?,
    val latencyMillis: Long,
)

internal class ProviderHttpTransport(
    private val baseClient: OkHttpClient,
    private val nanoTime: () -> Long = System::nanoTime,
) {
    suspend fun execute(
        spec: ProviderSpec,
        adapter: ProviderWireAdapter,
        payload: ProviderRequestPayload,
        credential: StoredCredential,
        timeoutMillis: Long,
    ): TimedProviderResult {
        val endpoint = spec.inferenceEndpoint.toHttpUrl()
        EndpointAllowlist.requireExactHttps(endpoint, spec.inferenceEndpoint, spec.allowedInferenceHost)
        val request = Request.Builder()
            .url(endpoint)
            .header("Accept", "application/json")
            .apply { payload.headers.forEach { (name, value) -> header(name, value) } }
            .apply {
                if (spec.provider.name == "CODEX") {
                    credential.accountId?.let { header("Chatgpt-Account-Id", it) }
                }
            }
            .header("Authorization", "Bearer ${credential.accessToken}")
            .post(payload.bodyJson.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        val client = baseClient.newBuilder()
            .callTimeout(timeoutMillis, TimeUnit.MILLISECONDS)
            .build()
        val started = nanoTime()
        val response = try {
            client.newCall(request).await()
        } catch (error: IOException) {
            if (
                error is SocketTimeoutException || error is InterruptedIOException ||
                error.javaClass.simpleName.contains("Timeout")
            ) {
                throw InternalSdkException(InternalFailureKind.TIMEOUT)
            }
            throw InternalSdkException(InternalFailureKind.NETWORK_UNAVAILABLE)
        }
        response.use {
            val latency = ((nanoTime() - started) / 1_000_000L).coerceAtLeast(0)
            if (!it.isSuccessful) throw mapHttpFailure(it)
            val body = it.body?.readUtf8Bounded(MAX_RESPONSE_BYTES)
                ?: throw InternalSdkException(InternalFailureKind.INVALID_RESPONSE)
            val parsed = adapter.parse(body)
            return TimedProviderResult(
                wire = parsed,
                providerRequestId = safeRequestId(it) ?: parsed.responseId,
                latencyMillis = latency,
            )
        }
    }

    private fun mapHttpFailure(response: Response): InternalSdkException = when (response.code) {
        401, 403 -> InternalSdkException(
            InternalFailureKind.AUTHENTICATION_REQUIRED,
            httpStatus = response.code,
        )
        429 -> InternalSdkException(
            InternalFailureKind.RATE_LIMITED,
            retryAfterMillis = response.header("Retry-After")?.toLongOrNull()
                ?.takeIf { it in 0..86_400L }
                ?.times(1000L),
            safeRequestId = safeRequestId(response),
        )
        in 500..599 -> InternalSdkException(
            InternalFailureKind.PROVIDER_UNAVAILABLE,
            safeRequestId = safeRequestId(response),
        )
        408 -> InternalSdkException(InternalFailureKind.TIMEOUT)
        in 400..499 -> InternalSdkException(InternalFailureKind.INVALID_REQUEST)
        else -> InternalSdkException(InternalFailureKind.INVALID_RESPONSE)
    }

    private fun safeRequestId(response: Response): String? =
        (response.header("x-request-id") ?: response.header("request-id"))
            ?.takeIf { it.length in 1..256 && it.all { character -> character.code in 0x21..0x7e } }

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { continuation ->
        continuation.invokeOnCancellation { cancel() }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (continuation.isActive) continuation.resumeWith(Result.failure(e))
            }

            override fun onResponse(call: Call, response: Response) {
                if (continuation.isActive) continuation.resume(response) else response.close()
            }
        })
    }

    private companion object {
        const val MAX_RESPONSE_BYTES = 10L * 1024L * 1024L
    }
}
