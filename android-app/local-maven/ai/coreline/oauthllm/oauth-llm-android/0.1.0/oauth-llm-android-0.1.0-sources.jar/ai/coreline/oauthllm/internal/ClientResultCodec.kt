package ai.coreline.oauthllm.internal

import android.content.Intent
import ai.coreline.oauthllm.api.ConnectResult
import ai.coreline.oauthllm.api.LlmConnection
import ai.coreline.oauthllm.api.LlmProvider
import ai.coreline.oauthllm.api.OAuthLlmFailure
import ai.coreline.oauthllm.internal.http.InternalFailureKind
import ai.coreline.oauthllm.internal.http.InternalSdkException

internal object ClientResultCodec {
    const val EXTRA_RUNTIME_ID = "ai.coreline.oauthllm.runtimeId"
    const val EXTRA_PROVIDER_ID = "ai.coreline.oauthllm.providerId"
    const val EXTRA_DISPLAY_NAME = "ai.coreline.oauthllm.displayName"
    const val EXTRA_TRANSACTION_ID = "ai.coreline.oauthllm.transactionId"
    private const val EXTRA_STATUS = "ai.coreline.oauthllm.status"
    private const val EXTRA_PROFILE_ID = "ai.coreline.oauthllm.profileId"
    private const val EXTRA_FAILURE_CODE = "ai.coreline.oauthllm.failureCode"
    private const val EXTRA_RETRY_AFTER = "ai.coreline.oauthllm.retryAfterMillis"

    fun encode(result: ConnectResult): Intent = Intent().apply {
        when (result) {
            is ConnectResult.Connected -> {
                putExtra(EXTRA_STATUS, STATUS_CONNECTED)
                putExtra(EXTRA_PROFILE_ID, result.connection.profileId)
                putExtra(EXTRA_PROVIDER_ID, result.connection.provider.id)
                putExtra(EXTRA_DISPLAY_NAME, result.connection.displayName)
            }
            ConnectResult.Cancelled -> putExtra(EXTRA_STATUS, STATUS_CANCELLED)
            is ConnectResult.Failed -> {
                val failure = result.failure
                putExtra(EXTRA_STATUS, STATUS_FAILED)
                putExtra(EXTRA_FAILURE_CODE, failure.code.name)
                if (failure is OAuthLlmFailure.RateLimited) {
                    failure.retryAfterMillis?.let { putExtra(EXTRA_RETRY_AFTER, it) }
                }
            }
        }
    }

    fun decode(intent: Intent?, connectionLookup: (String) -> LlmConnection?): ConnectResult {
        if (intent == null) return ConnectResult.Cancelled
        return when (intent.getStringExtra(EXTRA_STATUS)) {
            STATUS_CONNECTED -> intent.getStringExtra(EXTRA_PROFILE_ID)
                ?.let(connectionLookup)
                ?.let(ConnectResult::Connected)
                ?: ConnectResult.Failed(OAuthLlmFailure.InvalidProviderResponse)
            STATUS_CANCELLED -> ConnectResult.Cancelled
            STATUS_FAILED -> ConnectResult.Failed(
                failureFromCode(
                    intent.getStringExtra(EXTRA_FAILURE_CODE),
                    intent.takeIf { it.hasExtra(EXTRA_RETRY_AFTER) }
                        ?.getLongExtra(EXTRA_RETRY_AFTER, 0L),
                ),
            )
            else -> ConnectResult.Failed(OAuthLlmFailure.InvalidProviderResponse)
        }
    }

    fun failure(error: InternalSdkException): OAuthLlmFailure = when (error.kind) {
        InternalFailureKind.NOT_CONNECTED -> OAuthLlmFailure.NotConnected
        InternalFailureKind.AUTHENTICATION_REQUIRED -> OAuthLlmFailure.AuthenticationRequired
        InternalFailureKind.NETWORK_UNAVAILABLE -> OAuthLlmFailure.NetworkUnavailable
        InternalFailureKind.RATE_LIMITED -> OAuthLlmFailure.RateLimited(error.retryAfterMillis)
        InternalFailureKind.PROVIDER_UNAVAILABLE -> OAuthLlmFailure.ProviderUnavailable
        InternalFailureKind.TIMEOUT -> OAuthLlmFailure.Timeout
        InternalFailureKind.INVALID_RESPONSE -> OAuthLlmFailure.InvalidProviderResponse
        InternalFailureKind.INVALID_REQUEST -> OAuthLlmFailure.InvalidRequest
        InternalFailureKind.USER_CANCELLED -> OAuthLlmFailure.UserCancelled
    }

    private fun failureFromCode(code: String?, retryAfterMillis: Long?): OAuthLlmFailure = when (code) {
        "NOT_CONNECTED" -> OAuthLlmFailure.NotConnected
        "AUTHENTICATION_REQUIRED" -> OAuthLlmFailure.AuthenticationRequired
        "NETWORK_UNAVAILABLE" -> OAuthLlmFailure.NetworkUnavailable
        "RATE_LIMITED" -> OAuthLlmFailure.RateLimited(retryAfterMillis)
        "PROVIDER_UNAVAILABLE" -> OAuthLlmFailure.ProviderUnavailable
        "TIMEOUT" -> OAuthLlmFailure.Timeout
        "INVALID_REQUEST" -> OAuthLlmFailure.InvalidRequest
        "USER_CANCELLED" -> OAuthLlmFailure.UserCancelled
        else -> OAuthLlmFailure.InvalidProviderResponse
    }

    private const val STATUS_CONNECTED = "connected"
    private const val STATUS_CANCELLED = "cancelled"
    private const val STATUS_FAILED = "failed"
}
