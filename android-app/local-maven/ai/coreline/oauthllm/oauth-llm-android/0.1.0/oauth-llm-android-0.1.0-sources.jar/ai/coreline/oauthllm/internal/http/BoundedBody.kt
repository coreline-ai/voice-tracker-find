package ai.coreline.oauthllm.internal.http

import okhttp3.ResponseBody
import okio.Buffer

/** Reads at most [maxBytes], including for chunked responses with no Content-Length. */
internal fun ResponseBody.readUtf8Bounded(maxBytes: Long): String {
    require(maxBytes > 0)
    val declaredLength = contentLength()
    if (declaredLength > maxBytes) throw InternalSdkException(InternalFailureKind.INVALID_RESPONSE)

    val source = source()
    val buffer = Buffer()
    var total = 0L
    while (total <= maxBytes) {
        val remainingProbe = maxBytes + 1L - total
        val read = source.read(buffer, minOf(8_192L, remainingProbe))
        if (read == -1L) return buffer.readString(Charsets.UTF_8)
        total += read
    }
    throw InternalSdkException(InternalFailureKind.INVALID_RESPONSE)
}
