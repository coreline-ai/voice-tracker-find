package ai.coreline.oauthllm.internal.auth

import java.security.SecureRandom

internal fun interface RandomSource {
    fun nextBytes(size: Int): ByteArray
}

internal object SecureRandomSource : RandomSource {
    private val random = SecureRandom()

    override fun nextBytes(size: Int): ByteArray = ByteArray(size).also(random::nextBytes)
}

