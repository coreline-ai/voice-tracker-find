package ai.coreline.oauthllm.internal

import java.util.concurrent.ConcurrentHashMap

internal object OAuthRuntimeRegistry {
    private val runtimes = ConcurrentHashMap<String, ClientRuntime>()

    fun register(id: String, runtime: ClientRuntime) {
        runtimes[id] = runtime
    }

    fun find(id: String?): ClientRuntime? = id?.let(runtimes::get)

    fun unregister(id: String) {
        runtimes.remove(id)
    }
}

