package ai.coreline.oauthllm.internal.auth

import java.security.MessageDigest
import java.util.Base64

internal data class PkcePair(
    val verifier: String,
    val challenge: String,
)

internal class PkceGenerator(
    private val random: RandomSource = SecureRandomSource,
) {
    fun create(byteCount: Int = 64): PkcePair {
        require(byteCount in 32..96) { "PKCE entropy must be between 32 and 96 bytes" }
        val verifier = base64Url(random.nextBytes(byteCount))
        require(verifier.length in 43..128) { "PKCE verifier length is outside RFC 7636 limits" }
        return PkcePair(verifier, challenge(verifier))
    }

    fun createHex(byteCount: Int = 32): PkcePair {
        require(byteCount in 32..64) { "PKCE entropy must be between 32 and 64 bytes" }
        val verifier = random.nextBytes(byteCount).joinToString("") { byte ->
            HEX[(byte.toInt() ushr 4) and 0x0f].toString() + HEX[byte.toInt() and 0x0f]
        }
        return PkcePair(verifier, challenge(verifier))
    }

    fun state(byteCount: Int = 32): String = base64Url(random.nextBytes(byteCount))

    fun nonce(byteCount: Int = 32): String = base64Url(random.nextBytes(byteCount))

    private fun challenge(verifier: String): String = base64Url(
        MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII)),
    )

    private fun base64Url(value: ByteArray): String =
        Base64.getUrlEncoder().withoutPadding().encodeToString(value)

    private companion object {
        const val HEX = "0123456789abcdef"
    }
}

