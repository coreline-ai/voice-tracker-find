package ai.coreline.oauthllm.internal

import android.content.Context
import android.content.Intent
import android.net.Uri
import ai.coreline.oauthllm.android.AndroidOAuthLlmConfiguration
import ai.coreline.oauthllm.android.OAuthProviderRegistration
import ai.coreline.oauthllm.api.ConnectResult
import ai.coreline.oauthllm.api.DisconnectResult
import ai.coreline.oauthllm.api.DisconnectStatus
import ai.coreline.oauthllm.api.LlmConnection
import ai.coreline.oauthllm.api.LlmConnectionStatus
import ai.coreline.oauthllm.api.LlmGenerateRequest
import ai.coreline.oauthllm.api.LlmGenerateResult
import ai.coreline.oauthllm.api.LlmProvider
import ai.coreline.oauthllm.api.OAuthLlmFailure
import ai.coreline.oauthllm.internal.auth.CallbackValidationResult
import ai.coreline.oauthllm.internal.auth.CallbackValidator
import ai.coreline.oauthllm.internal.auth.CredentialRefresher
import ai.coreline.oauthllm.internal.auth.EncryptedCredentialStore
import ai.coreline.oauthllm.internal.auth.EncryptedPendingTransactionStore
import ai.coreline.oauthllm.internal.auth.LoopbackCallbackServer
import ai.coreline.oauthllm.internal.auth.PendingAuthTransaction
import ai.coreline.oauthllm.internal.auth.PkceGenerator
import ai.coreline.oauthllm.internal.auth.SingleFlightRefresh
import ai.coreline.oauthllm.internal.auth.StoredCredential
import ai.coreline.oauthllm.internal.auth.TokenEndpointClient
import ai.coreline.oauthllm.internal.auth.XaiDiscoveryValidator
import ai.coreline.oauthllm.internal.auth.executeWithSingleRefresh
import ai.coreline.oauthllm.internal.crypto.KeystoreEncryptedRecordStore
import ai.coreline.oauthllm.internal.http.InternalFailureKind
import ai.coreline.oauthllm.internal.http.InternalSdkException
import ai.coreline.oauthllm.internal.http.ProviderHttpTransport
import ai.coreline.oauthllm.internal.provider.PkceKind
import ai.coreline.oauthllm.internal.provider.ProviderSpecs
import ai.coreline.oauthllm.internal.provider.ProviderWireAdapters
import androidx.browser.customtabs.CustomTabsIntent
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import net.openid.appauth.AuthorizationRequest
import net.openid.appauth.AuthorizationServiceConfiguration
import net.openid.appauth.ResponseTypeValues
import okhttp3.OkHttpClient
import java.io.Closeable
import java.net.BindException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

internal data class ConnectFlowHandle(
    val transactionId: String,
    val browserIntent: Intent?,
    val result: Deferred<ConnectResult>,
)

internal class ClientRuntime(
    private val context: Context,
    configuration: AndroidOAuthLlmConfiguration,
    private val now: () -> Long = System::currentTimeMillis,
) : Closeable {
    private val registrations: Map<LlmProvider, OAuthProviderRegistration>
    private val transactionTimeoutMillis: Long
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val recordStore = KeystoreEncryptedRecordStore(context)
    private val credentialStore = EncryptedCredentialStore(recordStore)
    private val pendingStore = EncryptedPendingTransactionStore(recordStore)
    private val pkceGenerator = PkceGenerator()
    private val httpClient = OkHttpClient.Builder()
        .followRedirects(false)
        .followSslRedirects(false)
        .retryOnConnectionFailure(false)
        .build()
    private val tokenClient: TokenEndpointClient
    private val refresh: SingleFlightRefresh
    private val transport = ProviderHttpTransport(httpClient)
    private val discovery = XaiDiscoveryValidator(httpClient)
    private val flows = ConcurrentHashMap<String, ActiveConnectFlow>()
    private val stateMutex = Mutex()
    private val mutableConnections = MutableStateFlow<List<LlmConnection>>(emptyList())

    val connections: StateFlow<List<LlmConnection>> = mutableConnections.asStateFlow()

    init {
        require(configuration.registrations.isNotEmpty()) { "At least one OAuth registration is required" }
        require(configuration.transactionTimeoutMillis in 60_000L..10 * 60_000L) {
            "transactionTimeoutMillis must be between one and ten minutes"
        }
        configuration.registrations.forEach { registration ->
            require(registration.clientId.length in 1..512) { "OAuth clientId length is invalid" }
            require(registration.clientId.none { it.isWhitespace() || it == '\r' || it == '\n' }) {
                "OAuth clientId contains invalid characters"
            }
        }
        require(configuration.registrations.map { it.provider }.distinct().size == configuration.registrations.size) {
            "Only one registration is allowed per Provider"
        }
        registrations = configuration.registrations.associateBy { it.provider }
        transactionTimeoutMillis = configuration.transactionTimeoutMillis
        tokenClient = TokenEndpointClient(httpClient, clientId = { providerId ->
            registrations.entries.firstOrNull { it.key.id == providerId }?.value?.clientId
                ?: throw InternalSdkException(InternalFailureKind.AUTHENTICATION_REQUIRED)
        }, now = now)
        refresh = SingleFlightRefresh(
            store = credentialStore,
            refresher = CredentialRefresher { credential, refreshToken ->
                val provider = providerById(credential.providerId)
                    ?: throw InternalSdkException(InternalFailureKind.AUTHENTICATION_REQUIRED)
                val spec = ProviderSpecs.forProvider(provider)
                tokenClient.refresh(spec, refreshToken)
            },
            now = now,
        )
        pendingStore.removeExpired(now())
        updateConnections()
    }

    suspend fun beginConnect(provider: LlmProvider, displayName: String?): ConnectFlowHandle {
        validateDisplayName(displayName)
        val registration = registrations[provider]
            ?: throw InternalSdkException(InternalFailureKind.INVALID_REQUEST)
        val spec = ProviderSpecs.forProvider(provider)
        if (provider == LlmProvider.XAI) discovery.validate(spec)

        val pkce = when (spec.pkceKind) {
            PkceKind.STANDARD -> pkceGenerator.create(64)
            PkceKind.LONG_BASE64_URL -> pkceGenerator.create(96)
            PkceKind.HEX -> pkceGenerator.createHex(32)
        }
        val createdAt = now()
        val transaction = PendingAuthTransaction(
            transactionId = UUID.randomUUID().toString(),
            providerId = provider.id,
            profileId = UUID.randomUUID().toString(),
            displayName = displayName,
            state = pkceGenerator.state(),
            nonce = pkceGenerator.nonce(),
            verifier = pkce.verifier,
            challenge = pkce.challenge,
            redirectUri = spec.redirectUri,
            createdAtEpochMillis = createdAt,
            expiresAtEpochMillis = createdAt + transactionTimeoutMillis,
        )
        val deferred = CompletableDeferred<ConnectResult>()
        val callbackServer = LoopbackCallbackServer(
            host = spec.redirectHost,
            port = spec.redirectPort,
            expectedPath = spec.redirectPath,
            allowedCorsOrigins = if (provider == LlmProvider.XAI) {
                setOf("https://auth.x.ai", "https://accounts.x.ai")
            } else emptySet(),
            onCallbackUri = { callbackUri ->
                scope.launch { handleCallback(transaction.transactionId, callbackUri) }
            },
        )
        try {
            callbackServer.start()
        } catch (_: BindException) {
            throw InternalSdkException(InternalFailureKind.PROVIDER_UNAVAILABLE)
        } catch (_: Exception) {
            throw InternalSdkException(InternalFailureKind.PROVIDER_UNAVAILABLE)
        }
        val active = ActiveConnectFlow(transaction, callbackServer, deferred)
        flows[transaction.transactionId] = active
        try {
            pendingStore.save(transaction)
        } catch (error: InternalSdkException) {
            flows.remove(transaction.transactionId)
            callbackServer.close()
            deferred.complete(ConnectResult.Failed(ClientResultCodec.failure(error)))
            throw error
        }
        val browserIntent = try {
            authorizationIntent(spec, registration.clientId, transaction)
        } catch (_: Exception) {
            completeFlow(active, ConnectResult.Failed(OAuthLlmFailure.InvalidRequest))
            throw InternalSdkException(InternalFailureKind.INVALID_REQUEST)
        }
        active.timeoutJob = scope.launch {
            delay(transactionTimeoutMillis)
            completeFlow(active, ConnectResult.Failed(OAuthLlmFailure.Timeout))
        }
        return ConnectFlowHandle(transaction.transactionId, browserIntent, deferred)
    }

    fun attach(transactionId: String): ConnectFlowHandle? = flows[transactionId]?.let {
        ConnectFlowHandle(transactionId, browserIntent = null, result = it.result)
    }

    fun cancel(transactionId: String) {
        flows[transactionId]?.let { completeFlow(it, ConnectResult.Cancelled) }
    }

    fun release(transactionId: String) {
        flows.remove(transactionId)?.let {
            it.callbackServer.close()
            it.timeoutJob?.cancel()
            pendingStore.remove(transactionId)
        }
    }

    suspend fun generate(profileId: String, request: LlmGenerateRequest): LlmGenerateResult {
        if (profileId.isBlank() || profileId.length > 256) {
            throw InternalSdkException(InternalFailureKind.INVALID_REQUEST)
        }
        val initial = credentialStore.load(profileId)
            ?: throw InternalSdkException(InternalFailureKind.NOT_CONNECTED)
        val provider = providerById(initial.providerId)
            ?: throw InternalSdkException(InternalFailureKind.AUTHENTICATION_REQUIRED)
        if (registrations[provider] == null) {
            throw InternalSdkException(InternalFailureKind.AUTHENTICATION_REQUIRED)
        }
        val spec = ProviderSpecs.forProvider(provider)
        val adapter = ProviderWireAdapters.forProvider(provider)
        val payload = adapter.request(request)
        val credential = refresh.validCredential(profileId)
            ?: run {
                updateConnections()
                throw InternalSdkException(InternalFailureKind.AUTHENTICATION_REQUIRED)
            }
        return executeWithSingleRefresh(
            initial = credential,
            refreshRejected = { rejected ->
                refresh.validCredential(profileId, rejectedAccessToken = rejected.accessToken).also {
                    if (it == null) updateConnections()
                }
            },
            onFinalUnauthorized = {
                credentialStore.remove(profileId)
                updateConnections()
            },
            request = { activeCredential ->
                transport.execute(spec, adapter, payload, activeCredential, request.timeoutMillis)
                    .toPublic(profileId, provider)
            },
        )
    }

    suspend fun disconnect(profileId: String): DisconnectResult = stateMutex.withLock {
        if (profileId.isBlank() || profileId.length > 256) {
            throw InternalSdkException(InternalFailureKind.INVALID_REQUEST)
        }
        val existed = credentialStore.load(profileId) != null
        credentialStore.remove(profileId)
        updateConnections()
        DisconnectResult(
            profileId = profileId,
            status = if (existed) DisconnectStatus.DISCONNECTED else DisconnectStatus.ALREADY_DISCONNECTED,
        )
    }

    override fun close() {
        flows.values.forEach { flow ->
            flow.callbackServer.close()
            flow.timeoutJob?.cancel()
            pendingStore.remove(flow.transaction.transactionId)
            flow.result.cancel()
        }
        flows.clear()
        scope.cancel()
    }

    private suspend fun handleCallback(transactionId: String, callbackUri: String) {
        val active = flows[transactionId] ?: return
        val transaction = pendingStore.load(transactionId) ?: run {
            completeFlow(active, ConnectResult.Failed(OAuthLlmFailure.AuthenticationRequired))
            return
        }
        when (val validated = CallbackValidator.validate(callbackUri, transaction, now())) {
            is CallbackValidationResult.AuthorizationCode -> {
                if (!active.callbackClaimed.compareAndSet(false, true)) return
                val provider = providerById(transaction.providerId) ?: run {
                    completeFlow(active, ConnectResult.Failed(OAuthLlmFailure.AuthenticationRequired))
                    return
                }
                val result = try {
                    val credential = tokenClient.exchangeCode(
                        ProviderSpecs.forProvider(provider),
                        transaction,
                        validated.code,
                    )
                    credentialStore.save(credential)
                    updateConnections()
                    ConnectResult.Connected(credential.toConnection())
                } catch (error: InternalSdkException) {
                    ConnectResult.Failed(ClientResultCodec.failure(error))
                }
                completeFlow(active, result)
            }
            is CallbackValidationResult.ProviderError -> {
                val result = if (validated.error == "access_denied") {
                    ConnectResult.Cancelled
                } else {
                    ConnectResult.Failed(OAuthLlmFailure.AuthenticationRequired)
                }
                completeFlow(active, result)
            }
            is CallbackValidationResult.Rejected -> {
                if (validated.reason == ai.coreline.oauthllm.internal.auth.Rejection.EXPIRED) {
                    completeFlow(active, ConnectResult.Failed(OAuthLlmFailure.Timeout))
                }
                // Invalid or mismatched callbacks are ignored until a valid callback or timeout.
            }
        }
    }

    private fun completeFlow(active: ActiveConnectFlow, result: ConnectResult) {
        if (active.result.complete(result)) {
            active.callbackServer.close()
            active.timeoutJob?.cancel()
            runCatching { pendingStore.remove(active.transaction.transactionId) }
        }
    }

    private fun authorizationIntent(
        spec: ai.coreline.oauthllm.internal.provider.ProviderSpec,
        clientId: String,
        transaction: PendingAuthTransaction,
    ): Intent {
        val service = AuthorizationServiceConfiguration(
            Uri.parse(spec.authorizationEndpoint),
            Uri.parse(spec.tokenEndpoint),
        )
        val builder = AuthorizationRequest.Builder(
            service,
            clientId,
            ResponseTypeValues.CODE,
            Uri.parse(transaction.redirectUri),
        )
            .setScope(spec.scopes.joinToString(" "))
            .setState(transaction.state)
            .setCodeVerifier(transaction.verifier, transaction.challenge, "S256")
            .setAdditionalParameters(spec.authorizationExtras)
        if (spec.includeNonce) builder.setNonce(transaction.nonce)
        val authorizationUri = builder.build().toUri()
        return CustomTabsIntent.Builder()
            .setShowTitle(true)
            .build()
            .intent
            .setData(authorizationUri)
            .addCategory(Intent.CATEGORY_BROWSABLE)
    }

    private fun updateConnections() {
        mutableConnections.value = credentialStore.profiles()
            .mapNotNull { credential -> runCatching { credential.toConnection() }.getOrNull() }
            .sortedBy { it.profileId }
    }

    private fun StoredCredential.toConnection(): LlmConnection {
        val provider = providerById(providerId) ?: throw IllegalArgumentException()
        val canRefresh = !refreshToken.isNullOrBlank()
        val status = if (
            registrations[provider] != null &&
            (isUsable(now(), 0) || canRefresh)
        ) LlmConnectionStatus.CONNECTED else LlmConnectionStatus.AUTHENTICATION_REQUIRED
        return LlmConnection(
            profileId = profileId,
            provider = provider,
            displayName = displayName,
            status = status,
        )
    }

    private fun ai.coreline.oauthllm.internal.http.TimedProviderResult.toPublic(
        profileId: String,
        provider: LlmProvider,
    ): LlmGenerateResult = LlmGenerateResult(
        profileId = profileId,
        provider = provider,
        model = wire.model,
        text = wire.text,
        usage = wire.usage,
        providerRequestId = providerRequestId,
        latencyMillis = latencyMillis,
    )

    private fun providerById(id: String): LlmProvider? = LlmProvider.entries.firstOrNull { it.id == id }

    private fun validateDisplayName(displayName: String?) {
        if (displayName != null && (
                displayName.isBlank() || displayName.length > 128 ||
                    displayName.any { it == '\r' || it == '\n' }
                )
        ) throw InternalSdkException(InternalFailureKind.INVALID_REQUEST)
    }

    private class ActiveConnectFlow(
        val transaction: PendingAuthTransaction,
        val callbackServer: LoopbackCallbackServer,
        val result: CompletableDeferred<ConnectResult>,
        var timeoutJob: Job? = null,
        val callbackClaimed: AtomicBoolean = AtomicBoolean(false),
    )
}
