package ai.coreline.oauthllm.internal.auth

import java.io.Closeable
import java.io.InputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.nio.charset.StandardCharsets
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

internal class LoopbackCallbackServer(
    private val host: String,
    private val port: Int,
    private val expectedPath: String,
    private val allowedCorsOrigins: Set<String> = emptySet(),
    private val onCallbackUri: (String) -> Unit,
) : Closeable {
    private val running = AtomicBoolean(false)
    private val activeSockets = ConcurrentHashMap.newKeySet<Socket>()
    private val handlers = ThreadPoolExecutor(
        MAX_CONCURRENT_CLIENTS,
        MAX_CONCURRENT_CLIENTS,
        0L,
        TimeUnit.MILLISECONDS,
        ArrayBlockingQueue(MAX_QUEUED_CLIENTS),
        { task -> Thread(task, "oauth-llm-loopback-client-$port").apply { isDaemon = true } },
        ThreadPoolExecutor.AbortPolicy(),
    )
    private var serverSocket: ServerSocket? = null

    fun start() {
        check(running.compareAndSet(false, true)) { "Loopback callback server is already running" }
        try {
            serverSocket = ServerSocket(port, 4, InetAddress.getByName(host)).apply {
                reuseAddress = false
                soTimeout = 1_000
            }
        } catch (error: Exception) {
            running.set(false)
            throw error
        }
        Thread(::acceptLoop, "oauth-llm-loopback-$port").apply {
            isDaemon = true
            start()
        }
    }

    override fun close() {
        running.set(false)
        runCatching { serverSocket?.close() }
        serverSocket = null
        activeSockets.forEach { socket -> runCatching { socket.close() } }
        handlers.shutdownNow()
    }

    private fun acceptLoop() {
        while (running.get()) {
            val socket = try {
                serverSocket?.accept() ?: return
            } catch (_: java.net.SocketTimeoutException) {
                continue
            } catch (_: SocketException) {
                return
            } catch (_: Exception) {
                continue
            }
            activeSockets.add(socket)
            try {
                handlers.execute {
                    socket.use { runCatching { handle(it) } }
                    activeSockets.remove(socket)
                }
            } catch (_: java.util.concurrent.RejectedExecutionException) {
                activeSockets.remove(socket)
                runCatching { socket.close() }
            }
        }
    }

    private fun handle(socket: Socket) {
        socket.soTimeout = READ_TIMEOUT_MILLIS
        val input = socket.getInputStream()
        val requestLine = readLine(input, MAX_REQUEST_LINE_BYTES) ?: return
        val headers = readHeaders(input) ?: return
        val parts = requestLine.split(' ')
        if (parts.size != 3 || parts[2] != "HTTP/1.1") return respond(socket, 400)
        val method = parts[0]
        val target = parts[1]
        if (target.any { it == '\r' || it == '\n' } || target.length > MAX_REQUEST_LINE_BYTES) {
            return respond(socket, 400)
        }
        val path = target.substringBefore('?')
        if (path != expectedPath) return respond(socket, 404)
        if (method == "OPTIONS") {
            val origin = headers["origin"]
            return if (origin != null && origin in allowedCorsOrigins) {
                respondPreflight(socket, origin)
            } else {
                respond(socket, 403)
            }
        }
        if (method != "GET") return respond(socket, 405)
        val authority = if (host.contains(':')) "[$host]:$port" else "$host:$port"
        val callbackUri = "http://$authority$target"
        respondSuccess(socket)
        onCallbackUri(callbackUri)
    }

    private fun readHeaders(input: InputStream): Map<String, String>? {
        var count = 0
        var totalBytes = 0
        val result = linkedMapOf<String, String>()
        while (true) {
            val line = readLine(input, MAX_HEADER_LINE_BYTES) ?: return null
            if (line.isEmpty()) return result
            count++
            totalBytes += line.toByteArray(StandardCharsets.ISO_8859_1).size
            if (count > MAX_HEADER_COUNT || totalBytes > MAX_HEADER_BYTES) return null
            val separator = line.indexOf(':')
            if (separator <= 0) return null
            val name = line.substring(0, separator).trim().lowercase()
            val value = line.substring(separator + 1).trim()
            if (name.isBlank() || value.any { it == '\r' || it == '\n' }) return null
            if (result.put(name, value) != null) return null
        }
    }

    private fun readLine(input: InputStream, maxBytes: Int): String? {
        val bytes = ArrayList<Byte>(256)
        while (true) {
            val next = input.read()
            if (next < 0) return null
            if (next == '\n'.code) break
            if (next != '\r'.code) {
                if (bytes.size >= maxBytes) return null
                bytes.add(next.toByte())
            }
        }
        return bytes.toByteArray().toString(StandardCharsets.ISO_8859_1)
    }

    private fun respondSuccess(socket: Socket) {
        val html = "<!doctype html><meta charset=utf-8><title>OAuth completed</title>" +
            "<p>Authorization received. Return to the app.</p><script>window.close()</script>"
        val body = html.toByteArray(StandardCharsets.UTF_8)
        val headers = "HTTP/1.1 200 OK\r\n" +
            "Content-Type: text/html; charset=utf-8\r\n" +
            "Cache-Control: no-store\r\n" +
            "Content-Security-Policy: default-src 'none'; script-src 'unsafe-inline'\r\n" +
            "X-Content-Type-Options: nosniff\r\n" +
            "Content-Length: ${body.size}\r\nConnection: close\r\n\r\n"
        socket.getOutputStream().apply {
            write(headers.toByteArray(StandardCharsets.US_ASCII))
            write(body)
            flush()
        }
    }

    private fun respond(socket: Socket, status: Int) {
        val reason = when (status) {
            400 -> "Bad Request"
            403 -> "Forbidden"
            404 -> "Not Found"
            405 -> "Method Not Allowed"
            else -> "Error"
        }
        val response = "HTTP/1.1 $status $reason\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
        socket.getOutputStream().apply {
            write(response.toByteArray(StandardCharsets.US_ASCII))
            flush()
        }
    }

    private fun respondPreflight(socket: Socket, origin: String) {
        val response = "HTTP/1.1 204 No Content\r\n" +
            "Access-Control-Allow-Origin: $origin\r\n" +
            "Access-Control-Allow-Methods: GET, OPTIONS\r\n" +
            "Access-Control-Allow-Headers: *\r\n" +
            "Access-Control-Max-Age: 600\r\nVary: Origin\r\nConnection: close\r\n\r\n"
        socket.getOutputStream().apply {
            write(response.toByteArray(StandardCharsets.US_ASCII))
            flush()
        }
    }

    private companion object {
        const val READ_TIMEOUT_MILLIS = 2_000
        const val MAX_CONCURRENT_CLIENTS = 4
        const val MAX_QUEUED_CLIENTS = 8
        const val MAX_REQUEST_LINE_BYTES = 16 * 1024
        const val MAX_HEADER_LINE_BYTES = 8 * 1024
        const val MAX_HEADER_BYTES = 32 * 1024
        const val MAX_HEADER_COUNT = 64
    }
}
