package ai.coreline.oauthllm.internal.auth

import ai.coreline.oauthllm.internal.http.EndpointAllowlist
import ai.coreline.oauthllm.internal.http.InternalFailureKind
import ai.coreline.oauthllm.internal.http.InternalSdkException
import ai.coreline.oauthllm.internal.http.readUtf8Bounded
import ai.coreline.oauthllm.internal.provider.ProviderSpec
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import kotlin.coroutines.resume

internal class XaiDiscoveryValidator(
    client: OkHttpClient,
) {
    private val httpClient = client.newBuilder().followRedirects(false).build()

    suspend fun validate(spec: ProviderSpec) {
        val endpoint = DISCOVERY_ENDPOINT.toHttpUrl()
        EndpointAllowlist.requireExactHttps(endpoint, DISCOVERY_ENDPOINT, DISCOVERY_HOST)
        val response = try {
            httpClient.newCall(
                Request.Builder().url(endpoint).header("Accept", "application/json").get().build(),
            ).await()
        } catch (_: IOException) {
            throw InternalSdkException(InternalFailureKind.NETWORK_UNAVAILABLE)
        }
        response.use {
            if (!it.isSuccessful) throw InternalSdkException(InternalFailureKind.PROVIDER_UNAVAILABLE)
            val body = it.body?.readUtf8Bounded(MAX_DISCOVERY_BYTES)
                ?: throw InternalSdkException(InternalFailureKind.INVALID_RESPONSE)
            runCatching {
                val json = JSONObject(body)
                require(json.getString("issuer") == "https://auth.x.ai")
                require(json.getString("authorization_endpoint") == spec.authorizationEndpoint)
                require(json.getString("token_endpoint") == spec.tokenEndpoint)
                require(json.getString("jwks_uri") == spec.oidcJwksEndpoint)
                val algorithms = json.getJSONArray("id_token_signing_alg_values_supported")
                require((0 until algorithms.length()).any { algorithms.getString(it) == spec.oidcSigningAlgorithm })
            }.getOrElse { throw InternalSdkException(InternalFailureKind.INVALID_RESPONSE) }
        }
    }

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { continuation ->
        continuation.invokeOnCancellation { cancel() }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (continuation.isActive) continuation.resumeWith(Result.failure(e))
            }

            override fun onResponse(call: Call, response: Response) {
                if (continuation.isActive) continuation.resume(response) else response.close()
            }
        })
    }

    private companion object {
        const val DISCOVERY_ENDPOINT = "https://auth.x.ai/.well-known/openid-configuration"
        const val DISCOVERY_HOST = "auth.x.ai"
        const val MAX_DISCOVERY_BYTES = 64L * 1024L
    }
}
