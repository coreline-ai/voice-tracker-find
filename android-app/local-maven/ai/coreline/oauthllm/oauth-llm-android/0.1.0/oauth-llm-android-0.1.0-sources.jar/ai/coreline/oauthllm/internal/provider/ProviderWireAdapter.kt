package ai.coreline.oauthllm.internal.provider

import ai.coreline.oauthllm.api.JsonResponseSchema
import ai.coreline.oauthllm.api.LlmGenerateRequest
import ai.coreline.oauthllm.api.LlmMessageRole
import ai.coreline.oauthllm.api.LlmProvider
import ai.coreline.oauthllm.api.LlmUsage
import ai.coreline.oauthllm.internal.http.InternalFailureKind
import ai.coreline.oauthllm.internal.http.InternalSdkException
import org.json.JSONArray
import org.json.JSONObject

internal data class ProviderRequestPayload(
    val bodyJson: String,
    val headers: Map<String, String>,
)

internal data class ProviderWireResult(
    val text: String,
    val model: String,
    val usage: LlmUsage?,
    val responseId: String?,
)

internal interface ProviderWireAdapter {
    fun request(request: LlmGenerateRequest): ProviderRequestPayload
    fun parse(body: String): ProviderWireResult
}

internal object ProviderWireAdapters {
    fun forProvider(provider: LlmProvider): ProviderWireAdapter = when (provider) {
        LlmProvider.ANTHROPIC -> AnthropicWireAdapter
        LlmProvider.CODEX -> CodexWireAdapter
        LlmProvider.XAI -> XaiWireAdapter
    }
}

internal object RequestValidation {
    private val modelPattern = Regex("[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}")
    private val schemaNamePattern = Regex("[A-Za-z0-9][A-Za-z0-9_-]{0,63}")

    fun validate(request: LlmGenerateRequest) {
        invalidIf(request.operationId.isBlank() || request.operationId.length > 128)
        invalidIf(!request.model.matches(modelPattern))
        invalidIf(request.messages.isEmpty() || request.messages.size > 1_000)
        invalidIf(request.messages.any { it.content.isBlank() || it.content.length > 1_000_000 })
        invalidIf(request.messages.sumOf { it.content.length.toLong() } > 2_000_000L)
        invalidIf(request.maxOutputTokens !in 1..1_000_000)
        invalidIf(request.timeoutMillis !in 1_000L..300_000L)
        request.responseSchema?.let(::validateSchema)
    }

    private fun validateSchema(schema: JsonResponseSchema) {
        invalidIf(!schema.name.matches(schemaNamePattern))
        invalidIf(schema.schemaJson.length !in 2..65_536)
        val parsed = runCatching { JSONObject(schema.schemaJson) }.getOrNull()
        invalidIf(parsed == null)
    }

    private fun invalidIf(condition: Boolean) {
        if (condition) throw InternalSdkException(InternalFailureKind.INVALID_REQUEST)
    }
}

private object AnthropicWireAdapter : ProviderWireAdapter {
    override fun request(request: LlmGenerateRequest): ProviderRequestPayload {
        RequestValidation.validate(request)
        val body = JSONObject()
            .put("model", request.model)
            .put("max_tokens", request.maxOutputTokens)
            .put("messages", JSONArray().apply {
                request.messages.filter { it.role != LlmMessageRole.SYSTEM }.forEach { message ->
                    put(
                        JSONObject()
                            .put("role", message.role.name.lowercase())
                            .put(
                                "content",
                                JSONArray().put(JSONObject().put("type", "text").put("text", message.content)),
                            ),
                    )
                }
            })
        request.messages.filter { it.role == LlmMessageRole.SYSTEM }
            .joinToString("\n\n") { it.content }
            .takeIf(String::isNotBlank)
            ?.let { body.put("system", it) }
        request.responseSchema?.let { schema ->
            body.put(
                "output_config",
                JSONObject().put(
                    "format",
                    JSONObject()
                        .put("type", "json_schema")
                        .put("schema", JSONObject(schema.schemaJson)),
                ),
            )
        }
        if (body.getJSONArray("messages").length() == 0) {
            throw InternalSdkException(InternalFailureKind.INVALID_REQUEST)
        }
        return ProviderRequestPayload(
            bodyJson = body.toString(),
            headers = mapOf(
                "anthropic-version" to "2023-06-01",
                "anthropic-beta" to "oauth-2025-04-20",
            ),
        )
    }

    override fun parse(body: String): ProviderWireResult = safelyParse {
        val json = JSONObject(body)
        val content = json.getJSONArray("content")
        val text = buildString {
            repeat(content.length()) { index ->
                val block = content.getJSONObject(index)
                if (block.optString("type") == "text") append(block.getString("text"))
            }
        }
        require(text.isNotEmpty())
        val usage = json.optJSONObject("usage")?.let {
            normalizedUsage(it.getLong("input_tokens"), it.getLong("output_tokens"), null)
        }
        ProviderWireResult(
            text = text,
            model = json.getString("model"),
            usage = usage,
            responseId = json.optString("id").safeId(),
        )
    }
}

private object CodexWireAdapter : ProviderWireAdapter {
    override fun request(request: LlmGenerateRequest): ProviderRequestPayload {
        RequestValidation.validate(request)
        val input = JSONArray()
        request.messages.filter { it.role != LlmMessageRole.SYSTEM }.forEach { message ->
            input.put(
                JSONObject()
                    .put("role", message.role.name.lowercase())
                    .put("content", message.content),
            )
        }
        if (input.length() == 0) throw InternalSdkException(InternalFailureKind.INVALID_REQUEST)
        val body = JSONObject()
            .put("model", request.model)
            .put("stream", false)
            .put("store", false)
            .put("input", input)
            .put("max_output_tokens", request.maxOutputTokens)
        request.messages.filter { it.role == LlmMessageRole.SYSTEM }
            .joinToString("\n\n") { it.content }
            .takeIf(String::isNotBlank)
            ?.let { body.put("instructions", it) }
        request.responseSchema?.let { schema ->
            body.put(
                "text",
                JSONObject().put(
                    "format",
                    JSONObject()
                        .put("type", "json_schema")
                        .put("name", schema.name)
                        .put("strict", schema.strict)
                        .put("schema", JSONObject(schema.schemaJson)),
                ),
            )
        }
        return ProviderRequestPayload(
            bodyJson = body.toString(),
            headers = mapOf(
                "OpenAI-Beta" to "responses=experimental",
                "Originator" to "oauth-llm-sdk-android",
                "User-Agent" to "oauth-llm-sdk-android/0.1.0",
            ),
        )
    }

    override fun parse(body: String): ProviderWireResult = safelyParse {
        val json = JSONObject(body)
        require(json.optString("status") != "failed" && !json.has("error"))
        val output = json.getJSONArray("output")
        val text = buildString {
            repeat(output.length()) { outputIndex ->
                val item = output.getJSONObject(outputIndex)
                if (item.optString("type") == "message") {
                    val content = item.getJSONArray("content")
                    repeat(content.length()) { contentIndex ->
                        val part = content.getJSONObject(contentIndex)
                        if (part.optString("type") == "output_text") append(part.getString("text"))
                    }
                }
            }
        }
        require(text.isNotEmpty())
        val usage = json.optJSONObject("usage")?.let {
            normalizedUsage(it.getLong("input_tokens"), it.getLong("output_tokens"), null)
        }
        ProviderWireResult(
            text = text,
            model = json.optString("model").ifBlank { throw IllegalArgumentException() },
            usage = usage,
            responseId = json.optString("id").safeId(),
        )
    }
}

private object XaiWireAdapter : ProviderWireAdapter {
    override fun request(request: LlmGenerateRequest): ProviderRequestPayload {
        RequestValidation.validate(request)
        val body = JSONObject()
            .put("model", request.model)
            .put("max_tokens", request.maxOutputTokens)
            .put("stream", false)
            .put("messages", JSONArray().apply {
                request.messages.forEach { message ->
                    put(
                        JSONObject()
                            .put("role", message.role.name.lowercase())
                            .put("content", message.content),
                    )
                }
            })
        request.responseSchema?.let { schema ->
            body.put(
                "response_format",
                JSONObject()
                    .put("type", "json_schema")
                    .put(
                        "json_schema",
                        JSONObject()
                            .put("name", schema.name)
                            .put("strict", schema.strict)
                            .put("schema", JSONObject(schema.schemaJson)),
                    ),
            )
        }
        return ProviderRequestPayload(bodyJson = body.toString(), headers = emptyMap())
    }

    override fun parse(body: String): ProviderWireResult = safelyParse {
        val json = JSONObject(body)
        val choice = json.getJSONArray("choices").getJSONObject(0)
        val text = choice.getJSONObject("message").getString("content")
        require(text.isNotEmpty())
        val usage = json.optJSONObject("usage")?.let {
            normalizedUsage(
                it.getLong("prompt_tokens"),
                it.getLong("completion_tokens"),
                it.optLong("total_tokens").takeIf { value -> value > 0 },
            )
        }
        ProviderWireResult(
            text = text,
            model = json.getString("model"),
            usage = usage,
            responseId = json.optString("id").safeId(),
        )
    }
}

private inline fun safelyParse(block: () -> ProviderWireResult): ProviderWireResult =
    runCatching(block).getOrElse { throw InternalSdkException(InternalFailureKind.INVALID_RESPONSE) }

private fun normalizedUsage(input: Long, output: Long, total: Long?): LlmUsage {
    require(input >= 0 && output >= 0 && (total == null || total >= 0))
    return LlmUsage(inputTokens = input, outputTokens = output, totalTokens = total ?: input + output)
}

private fun String.safeId(): String? = takeIf {
    it.length in 1..256 && it.all { character -> character.code in 0x21..0x7e }
}

