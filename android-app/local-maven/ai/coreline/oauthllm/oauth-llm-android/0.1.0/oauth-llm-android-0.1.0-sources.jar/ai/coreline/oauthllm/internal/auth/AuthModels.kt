package ai.coreline.oauthllm.internal.auth

internal data class PendingAuthTransaction(
    val transactionId: String,
    val providerId: String,
    val profileId: String,
    val displayName: String?,
    val state: String,
    val nonce: String,
    val verifier: String,
    val challenge: String,
    val redirectUri: String,
    val createdAtEpochMillis: Long,
    val expiresAtEpochMillis: Long,
)

internal data class StoredCredential(
    val profileId: String,
    val providerId: String,
    val displayName: String?,
    val accessToken: String,
    val refreshToken: String?,
    val idToken: String?,
    val accountId: String?,
    val expiresAtEpochMillis: Long?,
    val updatedAtEpochMillis: Long,
) {
    fun isUsable(nowEpochMillis: Long, refreshSkewMillis: Long): Boolean =
        expiresAtEpochMillis == null || expiresAtEpochMillis - refreshSkewMillis > nowEpochMillis
}

internal data class TokenGrant(
    val accessToken: String,
    val refreshToken: String?,
    val idToken: String?,
    val accountId: String?,
    val expiresInSeconds: Long?,
)
