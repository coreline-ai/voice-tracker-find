package ai.coreline.oauthllm.internal.auth

import ai.coreline.oauthllm.internal.http.EndpointAllowlist
import ai.coreline.oauthllm.internal.http.InternalFailureKind
import ai.coreline.oauthllm.internal.http.InternalSdkException
import ai.coreline.oauthllm.internal.http.readUtf8Bounded
import ai.coreline.oauthllm.internal.provider.ProviderSpec
import ai.coreline.oauthllm.internal.provider.TokenEncoding
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.FormBody
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.io.InterruptedIOException
import java.net.SocketTimeoutException
import kotlin.coroutines.resume

internal class TokenEndpointClient(
    private val httpClient: OkHttpClient,
    private val clientId: (String) -> String,
    private val now: () -> Long = System::currentTimeMillis,
) {
    private val idTokenValidator = OidcIdTokenValidator(httpClient, now)

    suspend fun exchangeCode(
        spec: ProviderSpec,
        transaction: PendingAuthTransaction,
        authorizationCode: String,
    ): StoredCredential {
        val parameters = codeParameters(spec, transaction, authorizationCode)
        val grant = requestGrant(
            spec = spec,
            parameters = parameters,
            expectedNonce = transaction.nonce.takeIf { spec.includeNonce },
        )
        return StoredCredential(
            profileId = transaction.profileId,
            providerId = transaction.providerId,
            displayName = transaction.displayName,
            accessToken = grant.accessToken,
            refreshToken = grant.refreshToken,
            idToken = null,
            accountId = grant.accountId,
            expiresAtEpochMillis = grant.expiresInSeconds?.let { now() + it * 1000L },
            updatedAtEpochMillis = now(),
        )
    }

    internal fun codeParameters(
        spec: ProviderSpec,
        transaction: PendingAuthTransaction,
        authorizationCode: String,
    ): LinkedHashMap<String, String> {
        val parameters = linkedMapOf(
            "grant_type" to "authorization_code",
            "code" to authorizationCode,
            "redirect_uri" to transaction.redirectUri,
            "client_id" to clientId(spec.provider.id),
            "code_verifier" to transaction.verifier,
        )
        when (spec.provider.name) {
            "ANTHROPIC" -> parameters["state"] = transaction.state
            "XAI" -> {
                parameters["code_challenge"] = transaction.challenge
                parameters["code_challenge_method"] = "S256"
            }
        }
        return parameters
    }

    suspend fun refresh(spec: ProviderSpec, refreshToken: String): TokenGrant {
        val parameters = refreshParameters(spec, refreshToken)
        return requestGrant(spec, parameters, expectedNonce = null)
    }

    internal fun refreshParameters(
        spec: ProviderSpec,
        refreshToken: String,
    ): LinkedHashMap<String, String> {
        val parameters = linkedMapOf(
            "grant_type" to "refresh_token",
            "refresh_token" to refreshToken,
            "client_id" to clientId(spec.provider.id),
        )
        if (spec.provider.name == "CODEX") parameters["scope"] = spec.scopes.joinToString(" ")
        return parameters
    }

    private suspend fun requestGrant(
        spec: ProviderSpec,
        parameters: Map<String, String>,
        expectedNonce: String?,
    ): TokenGrant {
        val endpoint = spec.tokenEndpoint.toHttpUrl()
        EndpointAllowlist.requireExactHttps(endpoint, spec.tokenEndpoint, spec.allowedTokenHost)
        var attempt = 0
        while (true) {
            attempt++
            val request = Request.Builder()
                .url(endpoint)
                .header("Accept", "application/json")
                .post(requestBody(spec.tokenEncoding, parameters))
                .build()
            try {
                val response = httpClient.newCall(request).await()
                response.use { return parseResponse(spec, it, expectedNonce) }
            } catch (error: IOException) {
                if (attempt < spec.tokenNetworkAttempts) {
                    delay(1_000L shl (attempt - 1))
                    continue
                }
                if (error is SocketTimeoutException || error is InterruptedIOException) {
                    throw InternalSdkException(InternalFailureKind.TIMEOUT)
                }
                throw InternalSdkException(InternalFailureKind.NETWORK_UNAVAILABLE)
            }
        }
    }

    private fun requestBody(encoding: TokenEncoding, parameters: Map<String, String>): RequestBody =
        when (encoding) {
            TokenEncoding.JSON -> JSONObject(parameters).toString()
                .toRequestBody("application/json; charset=utf-8".toMediaType())
            TokenEncoding.FORM -> FormBody.Builder().apply {
                parameters.forEach { (name, value) -> add(name, value) }
            }.build()
        }

    private suspend fun parseResponse(
        spec: ProviderSpec,
        response: Response,
        expectedNonce: String?,
    ): TokenGrant {
        if (!response.isSuccessful) {
            throw when (response.code) {
                400, 401, 403 -> InternalSdkException(InternalFailureKind.AUTHENTICATION_REQUIRED)
                429 -> InternalSdkException(
                    InternalFailureKind.RATE_LIMITED,
                    retryAfterMillis = parseRetryAfterMillis(response.header("Retry-After")),
                    safeRequestId = safeRequestId(response),
                )
                in 500..599 -> InternalSdkException(
                    InternalFailureKind.PROVIDER_UNAVAILABLE,
                    safeRequestId = safeRequestId(response),
                )
                else -> InternalSdkException(InternalFailureKind.INVALID_RESPONSE)
            }
        }
        val body = response.body?.readUtf8Bounded(MAX_TOKEN_RESPONSE_BYTES)
            ?: throw InternalSdkException(InternalFailureKind.INVALID_RESPONSE)
        return runCatching {
            val json = JSONObject(body)
            val accessToken = json.getString("access_token").takeIf(String::isNotBlank)
                ?: throw IllegalArgumentException()
            val tokenType = json.optString("token_type", "Bearer")
            require(tokenType.equals("Bearer", ignoreCase = true))
            val expires = if (json.has("expires_in")) json.getLong("expires_in") else null
            require(expires == null || expires in 1..31_536_000L)
            val validatedClaims = if (expectedNonce != null) {
                idTokenValidator.validate(
                    encoded = json.getString("id_token"),
                    spec = spec,
                    expectedAudience = clientId(spec.provider.id),
                    expectedNonce = expectedNonce,
                )
            } else null
            val accountId = validatedClaims
                ?.optString("chatgpt_account_id")
                ?.takeIf { spec.provider.name == "CODEX" && isSafeAccountId(it) }
            TokenGrant(
                accessToken = accessToken,
                refreshToken = json.optString("refresh_token").takeIf(String::isNotBlank),
                idToken = null,
                accountId = accountId,
                expiresInSeconds = expires,
            )
        }.getOrElse { error ->
            if (error is InternalSdkException) throw error
            throw InternalSdkException(InternalFailureKind.INVALID_RESPONSE)
        }
    }

    private fun isSafeAccountId(value: String): Boolean =
        value.length in 1..256 && value.all { it.code in 0x21..0x7e }

    private fun parseRetryAfterMillis(value: String?): Long? = value?.toLongOrNull()
        ?.takeIf { it in 0..86_400L }
        ?.times(1000L)

    private fun safeRequestId(response: Response): String? =
        (response.header("x-request-id") ?: response.header("request-id"))
            ?.takeIf { it.length in 1..256 && it.all { char -> char.code in 0x21..0x7e } }

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { continuation ->
        continuation.invokeOnCancellation { cancel() }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (continuation.isActive) continuation.resumeWith(Result.failure(e))
            }

            override fun onResponse(call: Call, response: Response) {
                if (continuation.isActive) continuation.resume(response)
                else response.close()
            }
        })
    }

    private companion object {
        const val MAX_TOKEN_RESPONSE_BYTES = 256L * 1024L
    }
}
