package ai.coreline.oauthllm.internal.auth

import ai.coreline.oauthllm.internal.crypto.EncryptedRecordStore
import org.json.JSONArray
import org.json.JSONObject

internal class EncryptedPendingTransactionStore(
    private val records: EncryptedRecordStore,
) {
    fun save(transaction: PendingAuthTransaction) = synchronized(PENDING_STORE_LOCK) {
        records.put(TYPE, transaction.transactionId, transaction.toJson().toString())
        saveIndex(loadIndex() + transaction.transactionId)
    }

    fun load(transactionId: String): PendingAuthTransaction? = synchronized(PENDING_STORE_LOCK) {
        records.get(TYPE, transactionId)
            ?.let { encoded -> runCatching { JSONObject(encoded).toPendingTransaction() }.getOrNull() }
    }

    fun remove(transactionId: String) = synchronized(PENDING_STORE_LOCK) {
        records.remove(TYPE, transactionId)
        saveIndex(loadIndex() - transactionId)
    }

    fun removeExpired(nowEpochMillis: Long) = synchronized(PENDING_STORE_LOCK) {
        loadIndex().forEach { id ->
            val transaction = load(id)
            if (transaction == null || transaction.expiresAtEpochMillis < nowEpochMillis) remove(id)
        }
    }

    private fun loadIndex(): Set<String> = records.get(INDEX_TYPE, INDEX_ID)?.let { encoded ->
        runCatching {
            val array = JSONArray(encoded)
            buildSet { repeat(array.length()) { add(array.getString(it)) } }
        }.getOrNull()
    }.orEmpty()

    private fun saveIndex(ids: Set<String>) {
        records.put(INDEX_TYPE, INDEX_ID, JSONArray(ids.sorted()).toString())
    }

    private fun PendingAuthTransaction.toJson() = JSONObject()
        .put("transactionId", transactionId)
        .put("providerId", providerId)
        .put("profileId", profileId)
        .putOpt("displayName", displayName)
        .put("state", state)
        .put("nonce", nonce)
        .put("verifier", verifier)
        .put("challenge", challenge)
        .put("redirectUri", redirectUri)
        .put("createdAt", createdAtEpochMillis)
        .put("expiresAt", expiresAtEpochMillis)

    private fun JSONObject.toPendingTransaction() = PendingAuthTransaction(
        transactionId = getString("transactionId"),
        providerId = getString("providerId"),
        profileId = getString("profileId"),
        displayName = if (has("displayName") && !isNull("displayName")) {
            getString("displayName").takeIf(String::isNotBlank)
        } else null,
        state = getString("state"),
        nonce = getString("nonce"),
        verifier = getString("verifier"),
        challenge = getString("challenge"),
        redirectUri = getString("redirectUri"),
        createdAtEpochMillis = getLong("createdAt"),
        expiresAtEpochMillis = getLong("expiresAt"),
    )

    private companion object {
        val PENDING_STORE_LOCK = Any()
        const val TYPE = "pending"
        const val INDEX_TYPE = "pending_index"
        const val INDEX_ID = "transactions"
    }
}

internal class EncryptedCredentialStore(
    private val records: EncryptedRecordStore,
) : CredentialStore {
    override fun load(profileId: String): StoredCredential? = synchronized(CREDENTIAL_STORE_LOCK) {
        records.get(TYPE, profileId)
            ?.let { encoded -> runCatching { JSONObject(encoded).toCredential() }.getOrNull() }
    }

    override fun save(credential: StoredCredential) = synchronized(CREDENTIAL_STORE_LOCK) {
        records.put(TYPE, credential.profileId, credential.toJson().toString())
        val ids = loadIndex().toMutableSet().apply { add(credential.profileId) }
        saveIndex(ids)
    }

    override fun remove(profileId: String) = synchronized(CREDENTIAL_STORE_LOCK) {
        records.remove(TYPE, profileId)
        val ids = loadIndex().toMutableSet().apply { remove(profileId) }
        saveIndex(ids)
    }

    override fun profiles(): List<StoredCredential> = synchronized(CREDENTIAL_STORE_LOCK) {
        loadIndex().mapNotNull(::load)
    }

    private fun loadIndex(): Set<String> = records.get(INDEX_TYPE, INDEX_ID)?.let { encoded ->
        runCatching {
            val array = JSONArray(encoded)
            buildSet { repeat(array.length()) { add(array.getString(it)) } }
        }.getOrNull()
    }.orEmpty()

    private fun saveIndex(ids: Set<String>) {
        records.put(INDEX_TYPE, INDEX_ID, JSONArray(ids.sorted()).toString())
    }

    private fun StoredCredential.toJson() = JSONObject()
        .put("profileId", profileId)
        .put("providerId", providerId)
        .putOpt("displayName", displayName)
        .put("accessToken", accessToken)
        .putOpt("refreshToken", refreshToken)
        .putOpt("idToken", idToken)
        .putOpt("accountId", accountId)
        .putOpt("expiresAt", expiresAtEpochMillis)
        .put("updatedAt", updatedAtEpochMillis)

    private fun JSONObject.toCredential() = StoredCredential(
        profileId = getString("profileId"),
        providerId = getString("providerId"),
        displayName = optNullableString("displayName"),
        accessToken = getString("accessToken"),
        refreshToken = optNullableString("refreshToken"),
        idToken = optNullableString("idToken"),
        accountId = optNullableString("accountId"),
        expiresAtEpochMillis = if (has("expiresAt") && !isNull("expiresAt")) getLong("expiresAt") else null,
        updatedAtEpochMillis = getLong("updatedAt"),
    )

    private fun JSONObject.optNullableString(key: String): String? =
        if (has(key) && !isNull(key)) getString(key).takeIf(String::isNotBlank) else null

    private companion object {
        val CREDENTIAL_STORE_LOCK = Any()
        const val TYPE = "credential"
        const val INDEX_TYPE = "index"
        const val INDEX_ID = "profiles"
    }
}
