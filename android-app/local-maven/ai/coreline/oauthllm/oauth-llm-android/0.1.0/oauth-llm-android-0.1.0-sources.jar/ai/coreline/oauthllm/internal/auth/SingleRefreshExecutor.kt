package ai.coreline.oauthllm.internal.auth

import ai.coreline.oauthllm.internal.http.InternalFailureKind
import ai.coreline.oauthllm.internal.http.InternalSdkException

/** Executes one credential-bound request and permits exactly one refresh/replay after HTTP 401. */
internal suspend fun <T> executeWithSingleRefresh(
    initial: StoredCredential,
    refreshRejected: suspend (StoredCredential) -> StoredCredential?,
    onFinalUnauthorized: () -> Unit,
    request: suspend (StoredCredential) -> T,
): T {
    try {
        return request(initial)
    } catch (error: InternalSdkException) {
        if (error.kind != InternalFailureKind.AUTHENTICATION_REQUIRED || error.httpStatus != 401) {
            throw error
        }
    }
    val refreshed = refreshRejected(initial)
        ?: throw InternalSdkException(InternalFailureKind.AUTHENTICATION_REQUIRED, httpStatus = 401)
    return try {
        request(refreshed)
    } catch (error: InternalSdkException) {
        if (error.kind == InternalFailureKind.AUTHENTICATION_REQUIRED && error.httpStatus == 401) {
            onFinalUnauthorized()
        }
        throw error
    }
}

