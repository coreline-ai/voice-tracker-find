package ai.coreline.oauthllm.api

/** Consumer-visible state of a connected profile. */
public enum class LlmConnectionStatus {
    CONNECTED,
    AUTHENTICATION_REQUIRED,
}

/**
 * A provider profile known to the SDK.
 *
 * This deliberately contains only display-safe metadata. Authentication credentials and provider
 * protocol objects are never part of the public profile model.
 */
public data class LlmConnection(
    public val profileId: String,
    public val provider: LlmProvider,
    public val displayName: String? = null,
    public val status: LlmConnectionStatus = LlmConnectionStatus.CONNECTED,
)

/** Outcome of deleting the locally held credentials for a profile. */
public data class DisconnectResult(
    public val profileId: String,
    public val status: DisconnectStatus,
)

public enum class DisconnectStatus {
    DISCONNECTED,
    ALREADY_DISCONNECTED,
}
