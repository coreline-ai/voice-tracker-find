package ai.coreline.oauthllm.api

import java.io.Closeable
import kotlinx.coroutines.flow.StateFlow

/** Android-independent session API. Interactive connection is supplied by the Android artifact. */
public interface LlmSessionClient : Closeable {
    public val connections: StateFlow<List<LlmConnection>>

    @Throws(OAuthLlmException::class)
    public suspend fun generate(
        profileId: String,
        request: LlmGenerateRequest,
    ): LlmGenerateResult

    @Throws(OAuthLlmException::class)
    public suspend fun disconnect(profileId: String): DisconnectResult
}
