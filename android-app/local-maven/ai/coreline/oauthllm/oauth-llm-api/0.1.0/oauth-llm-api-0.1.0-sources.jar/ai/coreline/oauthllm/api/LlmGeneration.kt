package ai.coreline.oauthllm.api

public enum class LlmMessageRole {
    SYSTEM,
    USER,
    ASSISTANT,
}

public data class LlmMessage(
    public val role: LlmMessageRole,
    public val content: String,
)

/** Provider-neutral JSON response constraint supplied by the consumer. */
public data class JsonResponseSchema(
    public val name: String,
    public val schemaJson: String,
    public val strict: Boolean = true,
)

public data class LlmGenerateRequest(
    public val operationId: String,
    public val model: String,
    public val messages: List<LlmMessage>,
    public val maxOutputTokens: Int,
    public val responseSchema: JsonResponseSchema? = null,
    public val timeoutMillis: Long,
)

/** Normalized token counts. A provider may omit [totalTokens]. */
public data class LlmUsage(
    public val inputTokens: Long,
    public val outputTokens: Long,
    public val totalTokens: Long? = null,
)

public data class LlmGenerateResult(
    public val profileId: String,
    public val provider: LlmProvider,
    public val model: String,
    public val text: String,
    public val usage: LlmUsage?,
    public val providerRequestId: String?,
    public val latencyMillis: Long,
)
