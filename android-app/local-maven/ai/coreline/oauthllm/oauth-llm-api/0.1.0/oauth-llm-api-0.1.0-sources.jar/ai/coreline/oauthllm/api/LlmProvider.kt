package ai.coreline.oauthllm.api

/** OAuth-capable LLM services supported by this SDK. */
public enum class LlmProvider(public val id: String) {
    ANTHROPIC("anthropic"),
    CODEX("codex"),
    XAI("xai"),
}
