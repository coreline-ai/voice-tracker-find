package ai.coreline.oauthllm.api

/** Starts an interactive OAuth connection for [provider]. */
public data class ConnectRequest(
    public val provider: LlmProvider,
    public val displayName: String? = null,
)

/** Redacted result returned after an Android-hosted OAuth flow finishes. */
public sealed interface ConnectResult {
    public data class Connected(public val connection: LlmConnection) : ConnectResult

    public data object Cancelled : ConnectResult

    public data class Failed(public val failure: OAuthLlmFailure) : ConnectResult
}
