package ai.coreline.oauthllm.api

/** Stable, provider-neutral category suitable for application policy and telemetry. */
public enum class OAuthLlmFailureCode {
    NOT_CONNECTED,
    AUTHENTICATION_REQUIRED,
    NETWORK_UNAVAILABLE,
    RATE_LIMITED,
    PROVIDER_UNAVAILABLE,
    TIMEOUT,
    INVALID_PROVIDER_RESPONSE,
    INVALID_REQUEST,
    USER_CANCELLED,
}

/**
 * A redacted failure that lets a consuming application make its own retry and local-fallback
 * decisions.
 *
 * No subtype carries an authorization credential, authorization code, PKCE value, raw HTTP
 * object, or provider response body.
 */
public sealed class OAuthLlmFailure(
    public open val code: OAuthLlmFailureCode,
    public open val retryable: Boolean,
    public open val fallbackEligible: Boolean,
) {
    public data object NotConnected : OAuthLlmFailure(
        code = OAuthLlmFailureCode.NOT_CONNECTED,
        retryable = false,
        fallbackEligible = true,
    )

    public data object AuthenticationRequired : OAuthLlmFailure(
        code = OAuthLlmFailureCode.AUTHENTICATION_REQUIRED,
        retryable = false,
        fallbackEligible = true,
    )

    public data object NetworkUnavailable : OAuthLlmFailure(
        code = OAuthLlmFailureCode.NETWORK_UNAVAILABLE,
        retryable = true,
        fallbackEligible = true,
    )

    public data class RateLimited(
        public val retryAfterMillis: Long?,
    ) : OAuthLlmFailure(
        code = OAuthLlmFailureCode.RATE_LIMITED,
        retryable = true,
        fallbackEligible = true,
    )

    public data object ProviderUnavailable : OAuthLlmFailure(
        code = OAuthLlmFailureCode.PROVIDER_UNAVAILABLE,
        retryable = true,
        fallbackEligible = true,
    )

    public data object Timeout : OAuthLlmFailure(
        code = OAuthLlmFailureCode.TIMEOUT,
        retryable = true,
        fallbackEligible = true,
    )

    public data object InvalidProviderResponse : OAuthLlmFailure(
        code = OAuthLlmFailureCode.INVALID_PROVIDER_RESPONSE,
        retryable = false,
        fallbackEligible = true,
    )

    public data object InvalidRequest : OAuthLlmFailure(
        code = OAuthLlmFailureCode.INVALID_REQUEST,
        retryable = false,
        fallbackEligible = false,
    )

    public data object UserCancelled : OAuthLlmFailure(
        code = OAuthLlmFailureCode.USER_CANCELLED,
        retryable = false,
        fallbackEligible = false,
    )
}

/**
 * Public exception wrapper for operations that cannot return a normal result.
 *
 * The constructor intentionally accepts no message or cause so an implementation cannot expose a
 * raw provider error body through the public exception chain.
 */
public class OAuthLlmException(
    public val failure: OAuthLlmFailure,
) : Exception("OAuth LLM operation failed (${failure.code.name}).")
